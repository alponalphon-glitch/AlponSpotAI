package com.alpon.spotai

import android.os.Bundle
import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alpon.spotai.data.*
import com.alpon.spotai.domain.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private val Bg=Color(0xFF050A14); private val Panel=Color(0xFF101D31); private val Blue=Color(0xFF399BFF); private val Cyan=Color(0xFF43E5D2); private val Muted=Color(0xFF9AACC2); private val Green=Color(0xFF2DE6A6); private val Red=Color(0xFFFF647A); private val Gold=Color(0xFFE8B85D)
class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); window.statusBarColor=android.graphics.Color.rgb(5,10,20); window.navigationBarColor=android.graphics.Color.rgb(5,10,20); setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Blue,background=Bg,surface=Panel)) { SpotApp() } } } }
data class Holding(val symbol:String,val quantity:Double,val average:Double)
data class PaperPosition(
    val symbol:String,
    val quantity:Double,
    val entryPrice:Double,
    val invested:Double,
    val entryTime:Long,
    val entryRegime:String = "UNKNOWN"
)
data class PaperTrade(
    val symbol:String,
    val quantity:Double,
    val entryPrice:Double,
    val exitPrice:Double,
    val pnl:Double,
    val exitTime:Long,
    val entryTime:Long = 0L
)
data class ScanRow(val symbol:String,val price:Double,val change:Double,val signal:Signal)
class SpotViewModel(app:Application):AndroidViewModel(app){
    private val repo=BinanceRepository()
    private val candleDao=MarketDatabase.get(app).candleDao()
    private val historyRepo=MarketHistoryRepository(repo,candleDao)
    private val liveClient=OkHttpClient()
    @Volatile private var liveSocket:WebSocket?=null
    @Volatile private var liveGeneration=0
    var liveStatus by mutableStateOf("CONNECTING")
        private set
    private val newsRepo=CryptoNewsRepository()
    private val prefs=app.getSharedPreferences("portfolio",0)
    private val paperPrefs=app.getSharedPreferences("paper_trading",0)
    private val paperLossGuard=CapitalProtectionEngine.LossGuard(
        initialState=paperPrefs.getString("loss_guard",null)
    )
    var symbol by mutableStateOf("BTCUSDT"); private set
    var interval by mutableStateOf("1h"); private set
    var ticker by mutableStateOf<TickerDto?>(null); private set
    var candles by mutableStateOf<List<Candle>>(emptyList()); private set
    var historyLoading by mutableStateOf(false); private set
    var historyExhausted by mutableStateOf(false); private set
    var fullHistoryLoading by mutableStateOf(false); private set
    var fullHistoryDownloaded by mutableStateOf(0); private set
    var fullHistoryError by mutableStateOf<String?>(null); private set
    var historyStoredCount by mutableStateOf(0); private set
    var historyEarliestTime by mutableStateOf<Long?>(null); private set
    var historyLatestTime by mutableStateOf<Long?>(null); private set

    fun refreshHistoryStats(){
        val requestedSymbol = symbol
        val requestedInterval = interval

        viewModelScope.launch {
            try {
                val stats = withContext(Dispatchers.IO) {
                    Triple(
                        candleDao.countCandles(requestedSymbol, requestedInterval),
                        candleDao.getEarliestTime(requestedSymbol, requestedInterval),
                        candleDao.getLatestTime(requestedSymbol, requestedInterval)
                    )
                }

                if(requestedSymbol == symbol && requestedInterval == interval){
                    historyStoredCount = stats.first
                    historyEarliestTime = stats.second
                    historyLatestTime = stats.third
                }
            } catch(e: Exception) {
                if(requestedSymbol == symbol && requestedInterval == interval){
                    fullHistoryError = e.message ?: "Unable to read saved history statistics."
                }
            }
        }
    }
    var signal by mutableStateOf<Signal?>(null); private set
    var marketStructure by mutableStateOf<MarketStructureReport?>(null); private set
    var multiTimeframeSignal by mutableStateOf<MultiTimeframeSignal?>(null); private set
    var multiTimeframeError by mutableStateOf<String?>(null); private set
    var marketRegime by mutableStateOf<MarketRegimeReport?>(null); private set
    var priceActionReport by mutableStateOf<PriceActionReport?>(null); private set
    var smartMoneyReport by mutableStateOf<SmartMoneyReport?>(null); private set
    var aiAnalysisReport by mutableStateOf<AIAnalysisReport?>(null); private set
    var cognitiveReport by mutableStateOf<CognitiveIntelligenceReport?>(null); private set
    var backtestLoading by mutableStateOf(false); private set
    var backtestResult by mutableStateOf<BacktestResult?>(null); private set
    var backtestError by mutableStateOf<String?>(null); private set
    var walkForwardLoading by mutableStateOf(false); private set
    var walkForwardResult by mutableStateOf<WalkForwardResult?>(null); private set
    var walkForwardError by mutableStateOf<String?>(null); private set
    var paperBalance by mutableStateOf(10000.0); private set
    var paperPositions by mutableStateOf<List<PaperPosition>>(emptyList()); private set
    var paperTrades by mutableStateOf<List<PaperTrade>>(emptyList()); private set
    var paperMessage by mutableStateOf<String?>(null); private set


    private fun updateAiAnalysis() {
        marketRegime = MarketRegimeAnalysis.analyze(candles)
        smartMoneyReport = SmartMoneyAnalysis.analyze(candles, marketStructure)
        val base = AIAnalysisEngine.analyze(
            signal, multiTimeframeSignal, marketStructure, marketRegime, priceActionReport, smartMoneyReport
        )
        val learning = AdaptiveLearningEngine.evaluate(
            marketRegime?.regime ?: "UNKNOWN",
            AdaptiveLearningEngine.decode(paperPrefs.getString("adaptive_outcomes", null))
        )
        aiAnalysisReport = if (base == null) null else if (base.action == "BUY" && !learning.allowed) {
            val previousGate = base.qualityGate
            val gate = previousGate?.copy(
                allowed = false,
                action = "WAIT",
                blockers = previousGate.blockers + learning.explanation
            )
            base.copy(action = "WAIT", warnings = base.warnings + learning.explanation, qualityGate = gate)
        } else {
            base.copy(warnings = base.warnings + learning.explanation)
        }
        val paperEquity = paperBalance + paperPositions.sumOf { it.invested }
        val paperGuard = paperLossGuard.canOpenNewPosition(paperEquity, System.currentTimeMillis())
        paperPrefs.edit().putString("loss_guard", paperLossGuard.snapshot()).apply()
        cognitiveReport = CognitiveIntelligenceEngine.analyze(
            candles = candles,
            regime = marketRegime,
            structure = marketStructure,
            smartMoney = smartMoneyReport,
            signal = signal,
            ai = aiAnalysisReport,
            outcomes = AdaptiveLearningEngine.decode(paperPrefs.getString("adaptive_outcomes", null)),
            lossGuardAllowed = paperGuard.first,
            lossGuardReason = paperGuard.second,
            adaptiveRiskMultiplier = learning.riskMultiplier
        )
    }

    fun runBacktest(initialCapital: Double = 1000.0, riskPercent: Double = 0.5) {
        if (backtestLoading) return
        val requestedSymbol = symbol
        val requestedInterval = interval

        viewModelScope.launch {
            backtestLoading = true
            backtestError = null
            backtestResult = null
            try {
                val historyInfo = withContext(Dispatchers.IO) {
                    Pair(
                        candleDao.getEarliestTime(requestedSymbol, requestedInterval),
                        candleDao.countCandles(requestedSymbol, requestedInterval)
                    )
                }
                val firstTime = historyInfo.first
                val storedCount = historyInfo.second

                if (firstTime == null || storedCount < 211) {
                    if (requestedSymbol == symbol && requestedInterval == interval) {
                        backtestError = "Not enough saved candles. Download Binance history for this coin and timeframe first."
                    }
                    return@launch
                }

                // Room pages are streamed directly into the engine. The full history is never
                // collected into an ArrayList, so RAM usage stays bounded as history grows.
                val result = withContext(Dispatchers.Default) {
                    BacktestingEngine.runFromPages(
                        firstTime = firstTime,
                        interval = requestedInterval,
                        initialCapital = initialCapital,
                        riskPercent = riskPercent
                    ) { afterTime, limit ->
                        candleDao.getCandlesAfter(
                            requestedSymbol,
                            requestedInterval,
                            afterTime,
                            limit
                        ).map { it.toCandle() }
                    }
                }

                if (requestedSymbol == symbol && requestedInterval == interval) {
                    backtestResult = result
                    if (result == null) {
                        backtestError = "Not enough valid Binance candle history for backtesting."
                    }
                }
            } catch (e: Exception) {
                if (requestedSymbol == symbol && requestedInterval == interval) {
                    backtestError = e.message ?: "Backtesting failed."
                }
            } finally {
                backtestLoading = false
            }
        }
    }

    fun runWalkForward(initialCapital: Double = 1000.0, riskPercent: Double = 0.5) {
        if (walkForwardLoading) return
        val requestedSymbol = symbol
        val requestedInterval = interval
        viewModelScope.launch {
            walkForwardLoading = true
            walkForwardError = null
            walkForwardResult = null
            try {
                val bounds = withContext(Dispatchers.IO) {
                    Pair(
                        candleDao.getEarliestTime(requestedSymbol, requestedInterval),
                        candleDao.getLatestTime(requestedSymbol, requestedInterval)
                    )
                }
                val first = bounds.first
                val last = bounds.second
                if (first == null || last == null || last <= first) {
                    if (requestedSymbol == symbol && requestedInterval == interval) {
                        walkForwardError = "Not enough saved history. Download more Binance candles first."
                    }
                    return@launch
                }

                val result = withContext(Dispatchers.Default) {
                    WalkForwardEngine.run(
                        firstTime = first,
                        lastTime = last,
                        interval = requestedInterval,
                        initialCapital = initialCapital,
                        riskPercent = riskPercent
                    ) { afterTime, untilTime, limit ->
                        candleDao.getCandlesAfterUntil(
                            requestedSymbol, requestedInterval, afterTime, untilTime, limit
                        ).map { it.toCandle() }
                    }
                }
                if (requestedSymbol == symbol && requestedInterval == interval) {
                    walkForwardResult = result
                    if (result == null) walkForwardError = "History is too short for chronological walk-forward testing."
                }
            } catch (e: Exception) {
                if (requestedSymbol == symbol && requestedInterval == interval) {
                    walkForwardError = e.message ?: "Walk-forward validation failed."
                }
            } finally {
                walkForwardLoading = false
            }
        }
    }

    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var markets by mutableStateOf<List<TickerDto>>(emptyList()); private set
    var scanning by mutableStateOf(false); private set
    var scanRows by mutableStateOf<List<ScanRow>>(emptyList()); private set
    var holdings by mutableStateOf<List<Holding>>(emptyList()); private set
    var news by mutableStateOf<List<CryptoNewsItem>>(emptyList()); private set
    var newsLoading by mutableStateOf(false); private set
    var newsError by mutableStateOf<String?>(null); private set
    init {
        holdings = prefs.getString("holdings","")!!.split(";").mapNotNull { row ->
            val p=row.split("|")
            if(p.size==3) runCatching { Holding(p[0],p[1].toDouble(),p[2].toDouble()) }.getOrNull() else null
        }
        paperBalance = paperPrefs.getString("balance","10000")
            ?.toDoubleOrNull()?.takeIf { it.isFinite() && it>=0 } ?: 10000.0
        paperPositions = paperPrefs.getString("positions","").orEmpty().split(";").mapNotNull { row ->
            val p=row.split("|")
            if(p.size==5 || p.size==6) runCatching {
                PaperPosition(p[0],p[1].toDouble(),p[2].toDouble(),p[3].toDouble(),p[4].toLong(),p.getOrElse(5) { "UNKNOWN" })
            }.getOrNull()?.takeIf {
                it.symbol.matches(Regex("[A-Z0-9]{5,20}")) &&
                it.quantity.isFinite() && it.quantity>0 &&
                it.entryPrice.isFinite() && it.entryPrice>0 &&
                it.invested.isFinite() && it.invested>0 &&
                it.entryTime>0
            } else null
        }
        paperTrades = paperPrefs.getString("trades","").orEmpty().split(";").mapNotNull { row ->
            val p=row.split("|")
            if(p.size==6 || p.size==7) runCatching {
                PaperTrade(p[0],p[1].toDouble(),p[2].toDouble(),p[3].toDouble(),p[4].toDouble(),p[5].toLong(),p.getOrElse(6) { "0" }.toLong())
            }.getOrNull()?.takeIf {
                it.symbol.matches(Regex("[A-Z0-9]{5,20}")) &&
                it.quantity.isFinite() && it.quantity>0 &&
                it.entryPrice.isFinite() && it.entryPrice>0 &&
                it.exitPrice.isFinite() && it.exitPrice>0 &&
                it.pnl.isFinite() && it.exitTime>0
            } else null
        }
    }
    var scanInterval by mutableStateOf("1h"); private set
    fun select(s:String){symbol=s;historyExhausted=false;load()}
    fun changeInterval(v:String){interval=v;historyExhausted=false;load()}
    fun changeScanInterval(v:String){scanInterval=v;interval=v;historyExhausted=false;load()}
    fun load(){
        if (loading) return
        viewModelScope.launch {
            loading = true
            error = null
            val requestedSymbol = symbol
            val requestedInterval = interval
            multiTimeframeSignal = null
            priceActionReport = null
            multiTimeframeError = "Loading 12 Binance timeframes and long-horizon history…"

            try {
                // Show previously cached candles immediately while Binance refreshes.
                val cachedCandles = withContext(Dispatchers.IO) {
                    runCatching {
                        candleDao.getLatestCandles(
                            requestedSymbol,
                            requestedInterval,
                            1000
                        ).map { it.toCandle() }.reversed()
                    }.getOrDefault(emptyList())
                }

                if (cachedCandles.isNotEmpty() &&
                    requestedSymbol == symbol &&
                    requestedInterval == interval) {
                    candles = cachedCandles
                    signal = TechnicalAnalysis.analyze(cachedCandles, requestedInterval)
                    marketStructure = MarketStructureAnalysis.analyze(cachedCandles)
                    updateAiAnalysis()
                }

                val snap = repo.snapshot(requestedSymbol, requestedInterval)

                // Persist the latest Binance candles in Room.
                withContext(Dispatchers.IO) {
                    if (snap.candles.isNotEmpty()) {
                        candleDao.insertAll(
                            snap.candles.map {
                                it.toEntity(requestedSymbol, requestedInterval)
                            }
                        )
                    }
                }

                if (requestedSymbol == symbol && requestedInterval == interval) {
                    refreshHistoryStats()
                    ticker = snap.ticker
                    candles = snap.candles
                    signal = TechnicalAnalysis.analyze(snap.candles, requestedInterval)
                    marketStructure = MarketStructureAnalysis.analyze(snap.candles)
                    updateAiAnalysis()
                    if (signal == null) {
                        error = "Analysis unavailable: insufficient closed-candle history."
                    }
                }

                // Multi-timeframe analysis uses real Binance candles.
                if (requestedSymbol == symbol) {
                    try {
                        // Binance-native 12-frame context, from monthly macro trend to 5-minute execution.
                        val oneMonth = repo.candles(requestedSymbol, "1M")
                        val oneWeek = repo.candles(requestedSymbol, "1w")
                        val threeDay = repo.candles(requestedSymbol, "3d")
                        val daily = repo.candles(requestedSymbol, "1d")
                        val twelveHour = repo.candles(requestedSymbol, "12h")
                        val eightHour = repo.candles(requestedSymbol, "8h")
                        val fourHour = repo.candles(requestedSymbol, "4h")
                        val twoHour = repo.candles(requestedSymbol, "2h")
                        val hourly = repo.candles(requestedSymbol, "1h")
                        val thirtyMin = repo.candles(requestedSymbol, "30m")
                        val fifteenMin = repo.candles(requestedSymbol, "15m")
                        val fiveMin = repo.candles(requestedSymbol, "5m")

                        val result = MultiTimeframeAnalysis.analyze(
                            oneMonth, oneWeek, threeDay, daily, twelveHour, eightHour,
                            fourHour, twoHour, hourly, thirtyMin, fifteenMin, fiveMin
                        )
                        val priceAction = PriceActionAnalysis.analyze(daily, oneWeek, oneMonth)

                        if (requestedSymbol == symbol) {
                            multiTimeframeSignal = result
                            priceActionReport = priceAction
                            updateAiAnalysis()
                            multiTimeframeError = if (result == null) {
                                "Insufficient Binance candle history for all timeframes."
                            } else null
                        }
                    } catch (e: Exception) {
                        if (requestedSymbol == symbol) {
                            multiTimeframeSignal = null
                            updateAiAnalysis()
                            multiTimeframeError =
                                e.message ?: "Unable to load multi-timeframe Binance data."
                        }
                    }
                }
            } catch (e: Exception) {
                error = e.message ?: "Unable to load Binance market data."
                signal = null
            } finally {
                loading = false
            }
        }
    }

    fun downloadFullHistory(){
        if(fullHistoryLoading || loading) return

        val requestedSymbol = symbol
        val requestedInterval = interval

        viewModelScope.launch {
            fullHistoryLoading = true
            fullHistoryDownloaded = 0
            fullHistoryError = null

            try {
                val total = withContext(Dispatchers.IO) {
                    historyRepo.downloadFullHistory(
                        requestedSymbol,
                        requestedInterval
                    ) { downloaded, _ ->
                        viewModelScope.launch {
                            if(requestedSymbol == symbol &&
                                requestedInterval == interval) {
                                fullHistoryDownloaded = downloaded
                            }
                        }
                    }
                }

                if(requestedSymbol == symbol &&
                    requestedInterval == interval &&
                    total == 0) {
                    fullHistoryError =
                        "No new history downloaded. History may already be complete or unavailable."
                }
            } catch(e: Exception) {
                if(requestedSymbol == symbol &&
                    requestedInterval == interval) {
                    fullHistoryError =
                        e.message ?: "Full history download failed."
                }
            } finally {
                fullHistoryLoading = false
                if(requestedSymbol == symbol && requestedInterval == interval){
                    refreshHistoryStats()
                }
            }
        }
    }

    fun loadOlderHistory(){
        if(historyLoading || loading || historyExhausted || candles.isEmpty()) return
        val requestedSymbol=symbol
        val requestedInterval=interval
        val oldestTime=candles.first().time

        viewModelScope.launch {
            historyLoading=true
            try {
                val page=repo.candlesBefore(
                    requestedSymbol,
                    requestedInterval,
                    oldestTime-1L,
                    1000
                )

                if (page.isNotEmpty()) {
                    withContext(Dispatchers.IO) {
                        candleDao.insertAll(
                            page.map { it.toEntity(requestedSymbol, requestedInterval) }
                        )
                    }
                }

                if(requestedSymbol==symbol && requestedInterval==interval){
                    val merged=(page+candles)
                        .distinctBy{it.time}
                        .sortedBy{it.time}
                    candles=merged
                    signal=TechnicalAnalysis.analyze(merged,requestedInterval)
                    marketStructure=MarketStructureAnalysis.analyze(merged)
                    updateAiAnalysis()
                    if(page.isEmpty() || page.size<1000 ||
                        merged.firstOrNull()?.time==oldestTime){
                        historyExhausted=true
                    }
                    refreshHistoryStats()
                }
            }catch(e:Exception){
                error=e.message?:"Unable to load older Binance candles."
            }finally{
                historyLoading=false
            }
        }
    }

    fun startLiveStream(){
        val generation=++liveGeneration
        liveSocket?.close(1000,"Market changed")
        connectLiveStream(generation)
    }
    fun stopLiveStream(){liveGeneration++;liveSocket?.close(1000,"Screen closed");liveSocket=null;liveStatus="PAUSED"}
    private fun connectLiveStream(generation:Int){
        val streamSymbol=symbol.lowercase(Locale.US)
        val streamInterval=interval
        liveStatus="CONNECTING"
        val request=Request.Builder().url("wss://stream.binance.com:9443/stream?streams=${streamSymbol}@kline_${streamInterval}/${streamSymbol}@trade").build()
        liveSocket=liveClient.newWebSocket(request,object:WebSocketListener(){
            override fun onOpen(webSocket:WebSocket,response:Response){if(generation==liveGeneration)liveStatus="LIVE" else webSocket.close(1000,"Stale stream")}
            override fun onMessage(webSocket:WebSocket,text:String){
                if(generation!=liveGeneration)return
                runCatching {
                    val envelope=JSONObject(text);val root=envelope.optJSONObject("data") ?: envelope
                    if(root.optString("e")=="trade"){
                        val price=root.getString("p").toDouble();val old=candles
                        if(old.isNotEmpty()){
                            val last=old.last();val live=last.copy(high=maxOf(last.high,price),low=minOf(last.low,price),close=price)
                            candles=old.dropLast(1)+live
                        }
                        ticker=ticker?.copy(lastPrice=root.getString("p"))
                    } else if(root.optString("e")=="kline"){
                        val k=root.getJSONObject("k")
                        val candle=Candle(
                            time=k.getLong("t"),
                            open=k.getString("o").toDouble(),
                            high=k.getString("h").toDouble(),
                            low=k.getString("l").toDouble(),
                            close=k.getString("c").toDouble(),
                            volume=k.getString("v").toDouble(),
                            closeTime=k.optLong("T"),
                            quoteVolume=k.optString("q","0").toDoubleOrNull() ?: 0.0,
                            tradeCount=k.optLong("n"),
                            takerBuyBaseVolume=k.optString("V","0").toDoubleOrNull() ?: 0.0,
                            takerBuyQuoteVolume=k.optString("Q","0").toDoubleOrNull() ?: 0.0
                        )
                        val old=candles
                        candles=if(old.lastOrNull()?.time==candle.time) old.dropLast(1)+candle else if(old.any{it.time==candle.time}) old.map{if(it.time==candle.time)candle else it} else (old+candle)
                        ticker=ticker?.copy(lastPrice=k.getString("c"))
                        if(k.optBoolean("x",false)){
                            signal=TechnicalAnalysis.analyze(candles,streamInterval)
                            marketStructure=MarketStructureAnalysis.analyze(candles)
                            updateAiAnalysis()
                        }
                    }
                }
            }
            override fun onFailure(webSocket:WebSocket,t:Throwable,response:Response?){
                if(generation==liveGeneration){liveStatus="RECONNECTING";viewModelScope.launch{delay(3000);if(generation==liveGeneration)connectLiveStream(generation)}}
            }
            override fun onClosed(webSocket:WebSocket,code:Int,reason:String){if(generation==liveGeneration)liveStatus="DISCONNECTED"}
        })
    }
    fun loadMarkets(){viewModelScope.launch {try{markets=repo.topSpotUsdtMarkets(500)}catch(e:Exception){error=e.message?:"Unable to load Binance Spot markets."}}}
    fun loadNews(){ if(newsLoading) return; viewModelScope.launch { newsLoading=true; newsError=null; try { val latest=newsRepo.latest24Hours(); news=latest; if(latest.isEmpty()) newsError="No crypto headlines from the last 24 hours are available right now. Try again later." } catch(e:Exception) { newsError=e.message?:"Unable to load crypto news." } finally { newsLoading=false } } }
    fun scan(){viewModelScope.launch { scanning=true;scanRows= emptyList();try{val top=repo.allTickers().filter{it.symbol.endsWith("USDT") && !it.symbol.contains("UPUSDT") && !it.symbol.contains("DOWNUSDT")}.sortedByDescending{it.quoteVolume.toDoubleOrNull()?:0.0}.take(25); val rows= mutableListOf<ScanRow>(); for(t in top){ try{val c=repo.candles(t.symbol,scanInterval); val a=TechnicalAnalysis.analyze(c,scanInterval);if(a!=null && a.action!="WAIT") rows.add(ScanRow(t.symbol,t.lastPrice.toDouble(),t.priceChangePercent.toDouble(),a))}catch(_:Exception){}};scanRows=rows.sortedByDescending{it.signal.score} }catch(e:Exception){error=e.message?:"Scanner request failed."};scanning=false } }
    private fun persistHoldings(){prefs.edit().putString("holdings",holdings.joinToString(";"){"${it.symbol}|${it.quantity}|${it.average}"}).apply()}
    fun addHolding(h:Holding){holdings=(holdings.filterNot{it.symbol==h.symbol}+h);persistHoldings()}; fun removeHolding(h:Holding){holdings=holdings-h;persistHoldings()}
    fun currentPrice(s:String)=markets.firstOrNull{it.symbol==s}?.lastPrice?.toDoubleOrNull()

    private fun persistPaperTrading() {
        paperPrefs.edit()
            .putString("balance",paperBalance.toString())
            .putString("positions",paperPositions.joinToString(";") {
                "${it.symbol}|${it.quantity}|${it.entryPrice}|${it.invested}|${it.entryTime}|${it.entryRegime}"
            })
            .putString("trades",paperTrades.takeLast(200).joinToString(";") {
                "${it.symbol}|${it.quantity}|${it.entryPrice}|${it.exitPrice}|${it.pnl}|${it.exitTime}|${it.entryTime}"
            })
            .apply()
    }

    fun paperBuy(s:String,price:Double,amount:Double) {
        paperMessage=null
        val aiGate=aiAnalysisReport?.qualityGate
        if(aiAnalysisReport?.action!="BUY" || aiGate?.allowed!=true) {
            paperMessage="AI Trade Quality Gate: BUY is blocked. Wait for full confirmation."
            return
        }
        val equity=paperBalance+paperPositions.sumOf { it.invested }
        val guard=paperLossGuard.canOpenNewPosition(equity,System.currentTimeMillis())
        if(!guard.first) {
            paperMessage=guard.second
            return
        }
        val adaptive = AdaptiveLearningEngine.evaluate(
            marketRegime?.regime ?: "UNKNOWN",
            AdaptiveLearningEngine.decode(paperPrefs.getString("adaptive_outcomes", null))
        )
        if (!adaptive.allowed) {
            paperMessage = adaptive.explanation
            return
        }
        val adaptiveCap = equity * 0.25 * adaptive.riskMultiplier
        if(amount>adaptiveCap) {
            paperMessage="Adaptive capital protection: current regime caps this position at ${fmt(adaptiveCap)} USDT. ${adaptive.explanation}"
            return
        }
        if(s.isBlank() || !price.isFinite() || price<=0 ||
            !amount.isFinite() || amount<=0 ||
            !paperBalance.isFinite() || paperBalance<0) {
            paperMessage="Invalid market price, amount, or virtual balance."
            return
        }
        if(paperPositions.any{it.symbol==s}) {
            paperMessage="A Paper Trading position for $s is already open."
            return
        }
        val fee=amount*0.001
        val total=amount+fee
        val quantity=amount/price
        if(!fee.isFinite() || !total.isFinite() ||
            !quantity.isFinite() || quantity<=0) {
            paperMessage="Trade calculation is outside the supported numeric range."
            return
        }
        if(total>paperBalance) {
            paperMessage="Insufficient virtual balance, including the 0.1% fee."
            return
        }
        val newBalance=paperBalance-total
        if(!newBalance.isFinite() || newBalance<0) {
            paperMessage="Unable to safely calculate the remaining balance."
            return
        }
        paperBalance=newBalance
        paperPositions=paperPositions+PaperPosition(
            s,quantity,price,total,System.currentTimeMillis(),marketRegime?.regime ?: "UNKNOWN"
        )
        paperPrefs.edit().putString("loss_guard",paperLossGuard.snapshot()).apply()
        persistPaperTrading()
        paperMessage="Paper BUY executed: $s at ${fmt(price)}."
    }

    fun paperSell(s:String,price:Double) {
        paperMessage=null
        val position=paperPositions.firstOrNull{it.symbol==s}
        if(position==null) {
            paperMessage="No open Paper Trading position for $s."
            return
        }
        if(!price.isFinite() || price<=0 ||
            !position.quantity.isFinite() || position.quantity<=0 ||
            !position.entryPrice.isFinite() || position.entryPrice<=0 ||
            !position.invested.isFinite() || position.invested<=0) {
            paperMessage="Invalid position data or live market price."
            return
        }
        val gross=position.quantity*price
        val fee=gross*0.001
        val net=gross-fee
        val pnl=net-position.invested
        val newBalance=paperBalance+net
        if(!gross.isFinite() || gross<=0 || !fee.isFinite() ||
            !net.isFinite() || net<=0 || !pnl.isFinite() ||
            !newBalance.isFinite() || newBalance<0) {
            paperMessage="Trade calculation is outside the supported numeric range."
            return
        }
        paperBalance=newBalance
        val equityAfter=newBalance+paperPositions.filterNot{it.symbol==s}.sumOf { it.invested }
        paperLossGuard.recordClosedTrade(pnl,equityAfter,System.currentTimeMillis())
        paperPrefs.edit().putString("loss_guard",paperLossGuard.snapshot()).apply()
        paperPositions=paperPositions.filterNot{it.symbol==s}
        val exitTime = System.currentTimeMillis()
        paperTrades=(paperTrades+PaperTrade(
            s,position.quantity,position.entryPrice,price,pnl,exitTime,position.entryTime
        )).takeLast(200)
        val priorLearning = AdaptiveLearningEngine.decode(paperPrefs.getString("adaptive_outcomes", null))
        val outcome = AdaptiveTradeOutcome(
            position.entryRegime,
            if (position.invested > 0.0) pnl / position.invested * 100.0 else 0.0,
            exitTime
        )
        paperPrefs.edit().putString(
            "adaptive_outcomes",
            AdaptiveLearningEngine.encode((priorLearning + outcome).takeLast(100))
        ).apply()
        persistPaperTrading()
        paperMessage="Paper SELL executed: $s • PnL ${fmt(pnl)} USDT."
    }
}
private data class AppLanguage(val code:String,val name:String)
private val appLanguages = listOf(
    AppLanguage("en","English"), AppLanguage("es","Español"), AppLanguage("fr","Français"),
    AppLanguage("de","Deutsch"), AppLanguage("it","Italiano"), AppLanguage("pt","Português"),
    AppLanguage("ru","Русский"), AppLanguage("tg","Тоҷикӣ"), AppLanguage("tr","Türkçe"),
    AppLanguage("ar","العربية"), AppLanguage("zh","中文"), AppLanguage("ja","日本語"),
    AppLanguage("ko","한국어"), AppLanguage("hi","हिन्दी"), AppLanguage("id","Bahasa Indonesia"),
    AppLanguage("vi","Tiếng Việt"), AppLanguage("th","ไทย"), AppLanguage("fa","فارسی"),
    AppLanguage("ur","اردو"), AppLanguage("nl","Nederlands")
)
private val translations = mapOf(
    "es" to mapOf("Home" to "Inicio","Markets" to "Mercados","Scanner" to "Escáner","Portfolio" to "Cartera","Settings" to "Ajustes","My account" to "Mi cuenta","Support" to "Soporte","Language" to "Idioma","Select language" to "Seleccionar idioma","Menu" to "Menú","Account" to "Cuenta","Display name" to "Nombre visible","Save" to "Guardar","Cancel" to "Cancelar","Data source" to "Fuente de datos","Privacy & safety" to "Privacidad y seguridad","About" to "Acerca de","Back" to "Volver","Contact support" to "Contactar con soporte","Premium interface" to "Interfaz premium"),
    "fr" to mapOf("Home" to "Accueil","Markets" to "Marchés","Scanner" to "Scanner","Portfolio" to "Portefeuille","Settings" to "Paramètres","My account" to "Mon compte","Support" to "Assistance","Language" to "Langue","Select language" to "Choisir la langue","Menu" to "Menu","Account" to "Compte","Display name" to "Nom affiché","Save" to "Enregistrer","Cancel" to "Annuler","Data source" to "Source des données","Privacy & safety" to "Confidentialité et sécurité","About" to "À propos","Back" to "Retour","Contact support" to "Contacter l’assistance","Premium interface" to "Interface premium"),
    "de" to mapOf("Home" to "Start","Markets" to "Märkte","Scanner" to "Scanner","Portfolio" to "Portfolio","Settings" to "Einstellungen","My account" to "Mein Konto","Support" to "Support","Language" to "Sprache","Select language" to "Sprache auswählen","Menu" to "Menü","Account" to "Konto","Display name" to "Anzeigename","Save" to "Speichern","Cancel" to "Abbrechen","Data source" to "Datenquelle","Privacy & safety" to "Datenschutz & Sicherheit","About" to "Über","Back" to "Zurück","Contact support" to "Support kontaktieren","Premium interface" to "Premium-Oberfläche"),
    "it" to mapOf("Home" to "Home","Markets" to "Mercati","Scanner" to "Scanner","Portfolio" to "Portafoglio","Settings" to "Impostazioni","My account" to "Il mio account","Support" to "Supporto","Language" to "Lingua","Select language" to "Seleziona lingua","Menu" to "Menu","Account" to "Account","Display name" to "Nome visualizzato","Save" to "Salva","Cancel" to "Annulla","Data source" to "Fonte dati","Privacy & safety" to "Privacy e sicurezza","About" to "Informazioni","Back" to "Indietro","Contact support" to "Contatta il supporto","Premium interface" to "Interfaccia premium"),
    "pt" to mapOf("Home" to "Início","Markets" to "Mercados","Scanner" to "Scanner","Portfolio" to "Portfólio","Settings" to "Configurações","My account" to "Minha conta","Support" to "Suporte","Language" to "Idioma","Select language" to "Selecionar idioma","Menu" to "Menu","Account" to "Conta","Display name" to "Nome de exibição","Save" to "Salvar","Cancel" to "Cancelar","Data source" to "Fonte de dados","Privacy & safety" to "Privacidade e segurança","About" to "Sobre","Back" to "Voltar","Contact support" to "Contatar suporte","Premium interface" to "Interface premium"),
    "ru" to mapOf("Home" to "Главная","Markets" to "Рынки","Scanner" to "Сканер","Portfolio" to "Портфель","Settings" to "Настройки","My account" to "Мой аккаунт","Support" to "Поддержка","Language" to "Язык","Select language" to "Выберите язык","Menu" to "Меню","Account" to "Аккаунт","Display name" to "Отображаемое имя","Save" to "Сохранить","Cancel" to "Отмена","Data source" to "Источник данных","Privacy & safety" to "Конфиденциальность и безопасность","About" to "О приложении","Back" to "Назад","Contact support" to "Связаться с поддержкой","Premium interface" to "Премиум-интерфейс"),
    "tg" to mapOf("Home" to "Асосӣ","Markets" to "Бозорҳо","Scanner" to "Сканер","Portfolio" to "Портфел","Settings" to "Танзимот","My account" to "Ҳисоби ман","Support" to "Дастгирӣ","Language" to "Забон","Select language" to "Интихоби забон","Menu" to "Меню","Account" to "Ҳисоб","Display name" to "Номи намоишӣ","Save" to "Сабт кардан","Cancel" to "Бекор кардан","Data source" to "Манбаи маълумот","Privacy & safety" to "Махфият ва амният","About" to "Дар бораи барнома","Back" to "Бозгашт","Contact support" to "Тамос бо дастгирӣ","Premium interface" to "Интерфейси премиум"),
    "tr" to mapOf("Home" to "Ana Sayfa","Markets" to "Piyasalar","Scanner" to "Tarayıcı","Portfolio" to "Portföy","Settings" to "Ayarlar","My account" to "Hesabım","Support" to "Destek","Language" to "Dil","Select language" to "Dil seçin","Menu" to "Menü","Account" to "Hesap","Display name" to "Görünen ad","Save" to "Kaydet","Cancel" to "İptal","Data source" to "Veri kaynağı","Privacy & safety" to "Gizlilik ve güvenlik","About" to "Hakkında","Back" to "Geri","Contact support" to "Destek ile iletişim","Premium interface" to "Premium arayüz"),
    "ar" to mapOf("Home" to "الرئيسية","Markets" to "الأسواق","Scanner" to "الماسح","Portfolio" to "المحفظة","Settings" to "الإعدادات","My account" to "حسابي","Support" to "الدعم","Language" to "اللغة","Select language" to "اختر اللغة","Menu" to "القائمة","Account" to "الحساب","Display name" to "اسم العرض","Save" to "حفظ","Cancel" to "إلغاء","Data source" to "مصدر البيانات","Privacy & safety" to "الخصوصية والأمان","About" to "حول","Back" to "رجوع","Contact support" to "اتصل بالدعم","Premium interface" to "واجهة مميزة"),
    "zh" to mapOf("Home" to "首页","Markets" to "市场","Scanner" to "扫描器","Portfolio" to "投资组合","Settings" to "设置","My account" to "我的账户","Support" to "支持","Language" to "语言","Select language" to "选择语言","Menu" to "菜单","Account" to "账户","Display name" to "显示名称","Save" to "保存","Cancel" to "取消","Data source" to "数据来源","Privacy & safety" to "隐私与安全","About" to "关于","Back" to "返回","Contact support" to "联系支持","Premium interface" to "高级界面"),
    "ja" to mapOf("Home" to "ホーム","Markets" to "市場","Scanner" to "スキャナー","Portfolio" to "ポートフォリオ","Settings" to "設定","My account" to "マイアカウント","Support" to "サポート","Language" to "言語","Select language" to "言語を選択","Menu" to "メニュー","Account" to "アカウント","Display name" to "表示名","Save" to "保存","Cancel" to "キャンセル","Data source" to "データソース","Privacy & safety" to "プライバシーと安全","About" to "アプリについて","Back" to "戻る","Contact support" to "サポートに連絡","Premium interface" to "プレミアム画面"),
    "ko" to mapOf("Home" to "홈","Markets" to "시장","Scanner" to "스캐너","Portfolio" to "포트폴리오","Settings" to "설정","My account" to "내 계정","Support" to "지원","Language" to "언어","Select language" to "언어 선택","Menu" to "메뉴","Account" to "계정","Display name" to "표시 이름","Save" to "저장","Cancel" to "취소","Data source" to "데이터 소스","Privacy & safety" to "개인정보 및 보안","About" to "정보","Back" to "뒤로","Contact support" to "지원팀 문의","Premium interface" to "프리미엄 인터페이스"),
    "hi" to mapOf("Home" to "होम","Markets" to "बाज़ार","Scanner" to "स्कैनर","Portfolio" to "पोर्टफोलियो","Settings" to "सेटिंग्स","My account" to "मेरा खाता","Support" to "सहायता","Language" to "भाषा","Select language" to "भाषा चुनें","Menu" to "मेनू","Account" to "खाता","Display name" to "प्रदर्शित नाम","Save" to "सहेजें","Cancel" to "रद्द करें","Data source" to "डेटा स्रोत","Privacy & safety" to "गोपनीयता और सुरक्षा","About" to "जानकारी","Back" to "वापस","Contact support" to "सहायता से संपर्क करें","Premium interface" to "प्रीमियम इंटरफ़ेस"),
    "id" to mapOf("Home" to "Beranda","Markets" to "Pasar","Scanner" to "Pemindai","Portfolio" to "Portofolio","Settings" to "Pengaturan","My account" to "Akun saya","Support" to "Dukungan","Language" to "Bahasa","Select language" to "Pilih bahasa","Menu" to "Menu","Account" to "Akun","Display name" to "Nama tampilan","Save" to "Simpan","Cancel" to "Batal","Data source" to "Sumber data","Privacy & safety" to "Privasi & keamanan","About" to "Tentang","Back" to "Kembali","Contact support" to "Hubungi dukungan","Premium interface" to "Antarmuka premium"),
    "vi" to mapOf("Home" to "Trang chủ","Markets" to "Thị trường","Scanner" to "Bộ quét","Portfolio" to "Danh mục","Settings" to "Cài đặt","My account" to "Tài khoản của tôi","Support" to "Hỗ trợ","Language" to "Ngôn ngữ","Select language" to "Chọn ngôn ngữ","Menu" to "Menu","Account" to "Tài khoản","Display name" to "Tên hiển thị","Save" to "Lưu","Cancel" to "Hủy","Data source" to "Nguồn dữ liệu","Privacy & safety" to "Quyền riêng tư và bảo mật","About" to "Giới thiệu","Back" to "Quay lại","Contact support" to "Liên hệ hỗ trợ","Premium interface" to "Giao diện cao cấp"),
    "th" to mapOf("Home" to "หน้าหลัก","Markets" to "ตลาด","Scanner" to "สแกนเนอร์","Portfolio" to "พอร์ต","Settings" to "การตั้งค่า","My account" to "บัญชีของฉัน","Support" to "ช่วยเหลือ","Language" to "ภาษา","Select language" to "เลือกภาษา","Menu" to "เมนู","Account" to "บัญชี","Display name" to "ชื่อที่แสดง","Save" to "บันทึก","Cancel" to "ยกเลิก","Data source" to "แหล่งข้อมูล","Privacy & safety" to "ความเป็นส่วนตัวและความปลอดภัย","About" to "เกี่ยวกับ","Back" to "กลับ","Contact support" to "ติดต่อฝ่ายช่วยเหลือ","Premium interface" to "อินเทอร์เฟซพรีเมียม"),
    "fa" to mapOf("Home" to "خانه","Markets" to "بازارها","Scanner" to "اسکنر","Portfolio" to "سبد دارایی","Settings" to "تنظیمات","My account" to "حساب من","Support" to "پشتیبانی","Language" to "زبان","Select language" to "انتخاب زبان","Menu" to "منو","Account" to "حساب","Display name" to "نام نمایشی","Save" to "ذخیره","Cancel" to "لغو","Data source" to "منبع داده","Privacy & safety" to "حریم خصوصی و امنیت","About" to "درباره","Back" to "بازگشت","Contact support" to "تماس با پشتیبانی","Premium interface" to "رابط پریمیوم"),
    "ur" to mapOf("Home" to "ہوم","Markets" to "مارکیٹس","Scanner" to "اسکینر","Portfolio" to "پورٹ فولیو","Settings" to "ترتیبات","My account" to "میرا اکاؤنٹ","Support" to "مدد","Language" to "زبان","Select language" to "زبان منتخب کریں","Menu" to "مینو","Account" to "اکاؤنٹ","Display name" to "ظاہری نام","Save" to "محفوظ کریں","Cancel" to "منسوخ","Data source" to "ڈیٹا کا ذریعہ","Privacy & safety" to "رازداری اور تحفظ","About" to "تعارف","Back" to "واپس","Contact support" to "مدد سے رابطہ کریں","Premium interface" to "پریمیم انٹرفیس"),
    "nl" to mapOf("Home" to "Start","Markets" to "Markten","Scanner" to "Scanner","Portfolio" to "Portfolio","Settings" to "Instellingen","My account" to "Mijn account","Support" to "Ondersteuning","Language" to "Taal","Select language" to "Kies taal","Menu" to "Menu","Account" to "Account","Display name" to "Weergavenaam","Save" to "Opslaan","Cancel" to "Annuleren","Data source" to "Gegevensbron","Privacy & safety" to "Privacy en veiligheid","About" to "Over","Back" to "Terug","Contact support" to "Contact opnemen","Premium interface" to "Premium-interface")
)
private val newsTabLabels = mapOf(
    "en" to "News", "es" to "Noticias", "fr" to "Actualités", "de" to "Nachrichten", "it" to "Notizie",
    "pt" to "Notícias", "ru" to "Новости", "tg" to "Хабарҳо", "tr" to "Haberler", "ar" to "الأخبار",
    "zh" to "新闻", "ja" to "ニュース", "ko" to "뉴스", "hi" to "समाचार", "id" to "Berita",
    "vi" to "Tin tức", "th" to "ข่าว", "fa" to "اخبار", "ur" to "خبریں", "nl" to "Nieuws"
)
private fun tr(key:String,language:String):String = if(key=="News") newsTabLabels[language] ?: "News" else translations[language]?.get(key) ?: key

@Composable fun SpotApp(vm:SpotViewModel= viewModel()) {
    val context= LocalContext.current
    val prefs= remember { context.getSharedPreferences("app_preferences",0) }
    var language by remember { mutableStateOf(prefs.getString("language","en") ?: "en") }
    var tab by remember { mutableStateOf("Home") }
    var menuOpen by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit){vm.load();vm.loadMarkets()}
    // Binance WebSocket pushes the selected kline in real time; the REST snapshot seeds history.
    LaunchedEffect(tab,page,vm.symbol,vm.interval) {
        if((page==null && (tab=="Home" || tab=="Scanner" || tab=="ALPON")) || page=="Paper Trading") { vm.load(); vm.startLiveStream() }
        if(page==null && tab=="Markets") vm.loadMarkets()
        try { while(true) { if(page==null && tab=="Markets") vm.loadMarkets(); delay(60_000L) } }
        finally { vm.stopLiveStream() }
    }
    LaunchedEffect(tab,page,vm.scanInterval) {
        if (tab=="Scanner" && page==null) {
            while (true) { vm.scan(); delay(60_000L) }
        }
    }
    val nav=listOf("Home" to Icons.Default.ShowChart,"Markets" to Icons.Default.Explore,"ALPON" to Icons.Default.Psychology,"Portfolio" to Icons.Default.AccountBalanceWallet,"Settings" to Icons.Default.Tune)
    Scaffold(containerColor=Bg,bottomBar={
        if(page==null) NavigationBar(containerColor=Color(0xFF07111F),contentColor=Muted,modifier=Modifier.heightIn(min=72.dp)) {
            nav.forEach{(name,icon)->
                val label=when(name){"Home"->"Chart";"Portfolio"->"Funds";"ALPON"->"ALPON";else->tr(name,language)}
                NavigationBarItem(selected=tab==name,onClick={tab=name;if(name=="Markets")vm.loadMarkets();if(name=="ALPON")vm.scan()},
                    icon={Icon(icon,null,modifier=Modifier.size(if(tab==name)24.dp else 21.dp))},
                    label={Text(label,fontSize=10.sp,maxLines=1,fontWeight=if(tab==name)FontWeight.Bold else FontWeight.Medium)},
                    colors=NavigationBarItemDefaults.colors(selectedIconColor=Cyan,selectedTextColor=Cyan,indicatorColor=Blue.copy(alpha=.22f),unselectedIconColor=Muted,unselectedTextColor=Muted))
            }
        }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=14.dp)) {
            Row(Modifier.fillMaxWidth().padding(top=7.dp,bottom=11.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    if(page!=null) IconButton(onClick={page=null},modifier=Modifier.size(34.dp)) { Icon(Icons.Default.ArrowBack,null,tint=Cyan) }
                    else Image(painter=painterResource(R.drawable.alpon_robot_avatar),contentDescription="ALPON AI",contentScale=ContentScale.Crop,modifier=Modifier.size(42.dp).clip(CircleShape))
                    Spacer(Modifier.width(9.dp))
                    Column {
                        Text(if(page!=null) tr(page!!,language) else "ALPON",fontSize=if(page!=null)17.sp else 16.sp,color=Color.White,fontWeight=FontWeight.ExtraBold,letterSpacing=1.1.sp)
                        Text(if(page!=null) "INTELLIGENCE CONSOLE" else "SPOT AI  •  MARKET COMMAND",fontSize=8.sp,color=Cyan,fontWeight=FontWeight.SemiBold,letterSpacing=.8.sp)
                    }
                }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).background(if(vm.liveStatus=="LIVE") Green else Gold,CircleShape));Spacer(Modifier.width(5.dp));Text(if(vm.liveStatus=="LIVE") "LIVE" else "CONNECTING",fontSize=9.sp,color=Muted)
                    Box {
                        IconButton(onClick={menuOpen=true},modifier=Modifier.size(42.dp)) { Icon(Icons.Default.MoreVert,tr("Menu",language),tint=Gold) }
                        DropdownMenu(expanded=menuOpen,onDismissRequest={menuOpen=false},modifier=Modifier.background(Brush.linearGradient(listOf(Color(0xFF1B3552),Color(0xFF091322))),RoundedCornerShape(18.dp))) {
                            listOf("My account" to Icons.Default.Person,"Backtesting" to Icons.Default.ShowChart,"Paper Trading" to Icons.Default.SmartToy,"Settings" to Icons.Default.Settings,"Support" to Icons.Default.SupportAgent).forEach { (label,icon)->
                                DropdownMenuItem(text={Text(tr(label,language),color=Color.White,fontWeight=FontWeight.SemiBold)},leadingIcon={Icon(icon,null,tint=Gold)},onClick={menuOpen=false;page=label})
                            }
                        }
                    }
                }
            }
            when {
                page=="My account" -> AccountScreen(language)
                            page=="Backtesting" -> BacktestingScreen(vm)
                page=="Paper Trading" -> PaperTradingScreen(vm)
                page=="Settings" -> SettingsScreen(language){newLang->language=newLang;prefs.edit().putString("language",newLang).apply()}
                page=="Support" -> SupportScreen(language)
                else -> when(tab){"Home"->HomeScreen(vm);"Markets"->MarketsScreen(vm){tab="Home"};"ALPON"->AlponCommandCenter(vm){page=it};"Portfolio"->PortfolioScreen(vm);else->SettingsScreen(language){newLang->language=newLang;prefs.edit().putString("language",newLang).apply()}}
            }
        }
    }
}
@Composable fun CardBox(content:@Composable ColumnScope.()->Unit){
    Column(Modifier.fillMaxWidth().padding(bottom=12.dp).shadow(16.dp,RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color(0xFF1B3452),Color(0xFF102139),Color(0xFF0B1424))),RoundedCornerShape(20.dp)).padding(15.dp),content=content)
}
@Composable fun Section(title:String,tail:String?=null){Row(Modifier.fillMaxWidth().padding(bottom=12.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp);if(tail!=null)Text(tail,color=Muted,fontSize=11.sp)}}
@Composable fun MarketPairPicker(vm: SpotViewModel) {
    var open by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val matches = remember(query, vm.markets) {
        vm.markets.asSequence().filter { it.symbol.contains(query.trim().uppercase()) }.take(100).toList()
    }
    OutlinedButton(onClick = { query = ""; open = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Choose Binance Spot pair  •  ${vm.markets.size.coerceAtMost(500)} markets", fontSize = 12.sp)
            Icon(Icons.Default.ExpandMore, contentDescription = "Choose market")
        }
    }
    if (open) AlertDialog(
        onDismissRequest = { open = false },
        title = { Text("Binance Spot markets", color = Color.White) },
        text = {
            Column {
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search up to 500 USDT pairs") })
                Spacer(Modifier.height(8.dp))
                if (vm.markets.isEmpty()) Text("Market list is loading. Check your connection and refresh.", color = Muted, fontSize = 12.sp)
                else LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(matches, key = { it.symbol }) { market ->
                        Row(Modifier.fillMaxWidth().clickable { vm.select(market.symbol); open = false }.padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(market.symbol, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("24h volume ${compact(market.quoteVolume.toDoubleOrNull() ?: 0.0)} USDT", color = Muted, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(fmt(market.lastPrice.toDoubleOrNull() ?: 0.0), color = Color.White, fontSize = 12.sp)
                                val change = market.priceChangePercent.toDoubleOrNull() ?: 0.0
                                Text("${if (change >= 0) "+" else ""}${"%.2f".format(change)}%", color = if (change >= 0) Green else Red, fontSize = 11.sp)
                            }
                        }
                        HorizontalDivider(color = Muted.copy(alpha = .15f))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { open = false }) { Text("Close") } },
        containerColor = Panel
    )
}

@Composable fun AlponCommandCenter(vm:SpotViewModel,onOpenPage:(String)->Unit) {
    val context=LocalContext.current
    val prefs= remember { context.getSharedPreferences("app_preferences",0) }
    var autoPilot by remember { mutableStateOf(prefs.getBoolean("alpon_auto_paper",false)) }
    val price=if(vm.liveStatus=="LIVE" && vm.ticker?.symbol==vm.symbol) vm.ticker?.lastPrice?.toDoubleOrNull()?.takeIf{it.isFinite() && it>0} else null
    val position=vm.paperPositions.firstOrNull{it.symbol==vm.symbol}
    val report=vm.aiAnalysisReport
    LaunchedEffect(autoPilot,vm.liveStatus,vm.symbol,report?.action,position?.entryTime,vm.paperBalance) {
        if(autoPilot) {
            while(true) {
                delay(15_000L)
                val livePrice=if(vm.liveStatus=="LIVE" && vm.ticker?.symbol==vm.symbol) vm.ticker?.lastPrice?.toDoubleOrNull()?.takeIf{it.isFinite() && it>0} else null
                if(livePrice!=null) {
                    val open=vm.paperPositions.any{it.symbol==vm.symbol}
                    when {
                        !open && vm.aiAnalysisReport?.action=="BUY" && vm.aiAnalysisReport?.qualityGate?.allowed==true -> {
                            val amount=minOf(vm.paperBalance*0.10,500.0)
                            if(amount>=10.0) vm.paperBuy(vm.symbol,livePrice,amount)
                        }
                        open && vm.aiAnalysisReport?.action=="SELL" -> vm.paperSell(vm.symbol,livePrice)
                    }
                }
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        CardBox {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Image(painter=painterResource(R.drawable.alpon_robot_avatar),contentDescription="ALPON AI robot",contentScale=ContentScale.Crop,modifier=Modifier.size(76.dp).clip(CircleShape))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ALPON INTELLIGENCE",color=Gold,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                    Text("Trading command center",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.ExtraBold)
                    Text("${vm.symbol}  •  ${vm.interval.uppercase()}  •  ${if(vm.liveStatus=="LIVE")"LIVE MARKET" else "MARKET SYNCING"}",color=Muted,fontSize=10.sp)
                }
            }
            HorizontalDivider(Modifier.padding(vertical=12.dp),color=Muted.copy(alpha=.2f))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Column { Text("AI DECISION",color=Muted,fontSize=9.sp);Text(report?.action ?: "WAIT",color=when(report?.action){"BUY"->Green;"SELL"->Red;else->Cyan},fontSize=27.sp,fontWeight=FontWeight.Black) }
                Column(horizontalAlignment=Alignment.End) { Text("CONFIDENCE",color=Muted,fontSize=9.sp);Text(report?.let{"${it.confidence}%"} ?: "—",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold) }
            }
            Text(report?.qualityGate?.let{if(it.allowed) "Trade quality gate: PASSED" else "Trade quality gate: BLOCKED — WAIT"} ?: "Waiting for complete market analysis",color=if(report?.qualityGate?.allowed==true)Green else Gold,fontSize=11.sp,fontWeight=FontWeight.SemiBold)
            Text(price?.let{"${fmt(it)} USDT"} ?: "Waiting for live price",color=Color.White,fontSize=13.sp,modifier=Modifier.padding(top=5.dp))
        }
        Section("AUTONOMOUS PILOT",if(autoPilot) "PAPER MODE ACTIVE" else "MANUAL CONTROL")
        CardBox {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto Pilot",color=Color.White,fontSize=16.sp,fontWeight=FontWeight.Bold)
                    Text(if(autoPilot) "ALPON monitors signals every 15 seconds while this tab is open and manages virtual trades." else "Enable simulated automatic BUY / SELL using the AI quality gate.",color=Muted,fontSize=10.sp)
                }
                Switch(checked=autoPilot,onCheckedChange={autoPilot=it;prefs.edit().putBoolean("alpon_auto_paper",it).apply()},colors=SwitchDefaults.colors(checkedThumbColor=Color.White,checkedTrackColor=Green,uncheckedThumbColor=Muted))
            }
            Text("SIMULATION ONLY • No real Binance orders or real money",color=Gold,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=9.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={if(price!=null) vm.paperBuy(vm.symbol,price,minOf(vm.paperBalance*.10,500.0))},enabled=price!=null && position==null,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Color(0xFF062016))) { Text("PAPER BUY",fontSize=11.sp,fontWeight=FontWeight.Bold) }
                Button(onClick={if(price!=null) vm.paperSell(vm.symbol,price)},enabled=price!=null && position!=null,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Red)) { Text("PAPER SELL",fontSize=11.sp,fontWeight=FontWeight.Bold) }
            }
            OutlinedButton(onClick={onOpenPage("Paper Trading")},modifier=Modifier.fillMaxWidth()) { Text("POSITIONS & TRADE HISTORY",fontSize=10.sp) }
            vm.paperMessage?.let{Text(it,color=Cyan,fontSize=10.sp,modifier=Modifier.padding(top=6.dp))}
        }
        Section("FIVE INTELLIGENCE SYSTEMS","LIVE ANALYSIS")
        CognitiveIntelligenceCard(vm)
        Section("MARKET SCANNER","TOP OPPORTUNITIES")
        CardBox {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Text("Binance Spot scanner",color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp)
                TextButton(onClick={vm.scan()},enabled=!vm.scanning){Text(if(vm.scanning)"SCANNING…" else "SCAN NOW",color=Cyan)}
            }
            if(vm.scanning) LinearProgressIndicator(Modifier.fillMaxWidth(),color=Cyan)
            if(vm.scanRows.isEmpty()) Text("No qualified opportunities yet. Run a scan to refresh.",color=Muted,fontSize=11.sp)
            vm.scanRows.take(6).forEach { row ->
                Row(Modifier.fillMaxWidth().clickable{vm.select(row.symbol)}.padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)){Text(row.symbol,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp);Text("${fmt(row.price)} USDT",color=Muted,fontSize=10.sp)}
                    Column(horizontalAlignment=Alignment.End){Text(row.signal.action,color=if(row.signal.action=="BUY")Green else Red,fontWeight=FontWeight.Bold,fontSize=11.sp);Text("Score ${row.signal.score}",color=Muted,fontSize=9.sp)}
                }
                HorizontalDivider(color=Muted.copy(alpha=.12f))
            }
        }
        Section("ROBOT WORKSPACE","TOOLS & PERFORMANCE")
        CardBox {
            listOf("Paper Trading" to "Virtual execution, positions and trade history","Backtesting" to "Historical strategy performance","Walk-forward" to "Out-of-sample validation").forEach { (name,description) ->
                Row(Modifier.fillMaxWidth().clickable{onOpenPage(if(name=="Walk-forward")"Backtesting" else name)}.padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)){Text(name.uppercase(),color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp);Text(description,color=Muted,fontSize=10.sp)}
                    Icon(Icons.Default.ChevronRight,null,tint=Gold)
                }
                HorizontalDivider(color=Muted.copy(alpha=.12f))
            }
        }
        Text("ALPON provides rule-based market analysis and paper automation. It does not guarantee returns or place live exchange orders.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(bottom=14.dp))
    }
}

@Composable fun HomeScreen(vm:SpotViewModel){
    var pair by remember(vm.symbol){mutableStateOf(vm.symbol)}
    var showAllIndicators by remember { mutableStateOf(false) }
    LazyColumn(contentPadding=PaddingValues(bottom=16.dp)){
        item{CardBox{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("SELECTED MARKET",color=Muted,fontSize=10.sp);Text(pair,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold)};IconButton(onClick={vm.load()}){Icon(Icons.Default.Refresh,null,tint=Cyan)}};val t=vm.ticker;Text(t?.lastPrice?.toDoubleOrNull()?.let{fmt(it)}?:"—",fontSize=31.sp,color=Color.White,fontWeight=FontWeight.Bold);Text(t?.priceChangePercent?.let{"${if((it.toDoubleOrNull()?:0.0)>=0)"+" else ""}$it% (24h)"}?:"Waiting for market data",color=if((t?.priceChangePercent?.toDoubleOrNull()?:0.0)>=0)Green else Red);Text("24h quote volume  ${t?.quoteVolume?.toDoubleOrNull()?.let{compact(it)} ?: "—"} USDT",color=Muted,fontSize=11.sp);Spacer(Modifier.height(8.dp));MarketPairPicker(vm)}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("PRICE CHART",color=Color.White,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState())){listOf("15m","1h","4h","1d").forEach{FilterChip(selected=vm.interval==it,onClick={vm.changeInterval(it)},label={Text(it,fontSize=10.sp)})}}}}
        item{PremiumChartCard(vm)}
        item{if(vm.loading)LinearProgressIndicator(Modifier.fillMaxWidth(),color=Cyan);vm.error?.let{Text(it,color=Red,fontSize=12.sp,modifier=Modifier.padding(bottom=10.dp))}}
        item{Section("AI MARKET ANALYSIS","Rule-based • Live data") ; val s=vm.signal; if(s==null)CardBox{Text("Analysis unavailable",color=Muted)}else CardBox{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(s.action,fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=when(s.action){"BUY"->Green;"SELL"->Red;else->Cyan});Text("${s.score}/100",fontSize=18.sp,color=Color.White,fontWeight=FontWeight.Bold)};Text("${s.trend} trend",color=Muted);Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Entry",fmt(s.entry));Metric("Stop loss",fmt(s.stop));Metric("R:R", "1:${s.rr}")};Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Take profit 1",fmt(s.tp1));Metric("TP 2",fmt(s.tp2));Metric("TP 3",fmt(s.tp3))};HorizontalDivider(Modifier.padding(vertical=10.dp),color=Muted.copy(alpha=.2f));Text(s.explanation,color=Muted,fontSize=12.sp);Text("Indicators",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp,bottom=7.dp));Text("EMA 9  ${fmt(s.ema9)}   EMA 21  ${fmt(s.ema21)}",color=Muted,fontSize=11.sp);Text("EMA 50  ${fmt(s.ema50)}   EMA 200  ${fmt(s.ema200)}",color=Muted,fontSize=11.sp);Text("RSI  ${"%.1f".format(s.rsi)}   MACD  ${"%.5f".format(s.macd)}",color=Muted,fontSize=11.sp);Text("Support  ${fmt(s.support)}   Resistance  ${fmt(s.resistance)}",color=Muted,fontSize=11.sp);Spacer(Modifier.height(10.dp));Text("${s.indicators.size} technical readings • ${s.indicators.map{it.group}.distinct().size} indicator groups",color=Cyan,fontSize=10.sp,fontWeight=FontWeight.SemiBold);Text(if(showAllIndicators)"Hide full indicator matrix" else "View all technical indicators",color=Blue,fontSize=11.sp,fontWeight=FontWeight.Bold,modifier=Modifier.fillMaxWidth().clickable{showAllIndicators=!showAllIndicators}.padding(vertical=10.dp));if(showAllIndicators){s.indicators.groupBy{it.group}.forEach{(group,items)->Text(group.uppercase(),color=Cyan,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp,bottom=4.dp));items.forEach{item->Row(Modifier.fillMaxWidth().padding(vertical=3.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(item.name,color=Muted,fontSize=10.sp,modifier=Modifier.weight(1f));Text(item.value,color=Color.White,fontSize=10.sp);Text(when(item.bias){1->"BULLISH";-1->"BEARISH";else->"NEUTRAL"},color=when(item.bias){1->Green;-1->Red;else->Muted},fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.width(66.dp))}}}}}}
        item{AIEngineCard(vm)}
        item{CognitiveIntelligenceCard(vm)}
        item{MultiTimeframeCard(vm)}
        item{PriceActionCard(vm)}
        item{SmartMoneyCard(vm)}
        item{Text("Analysis only. No orders are placed. Signals are not financial advice.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(bottom=10.dp))}
    }
}


@Composable
fun AIEngineCard(vm: SpotViewModel) {
    val report = vm.aiAnalysisReport

    Section("AI DECISION ENGINE", "Indicators • Price Action • 12 timeframes • Structure")
    CardBox {
        if (report == null) {
            Text(
                "Waiting for complete market analysis...",
                color = Muted,
                fontSize = 12.sp
            )
            if (vm.loading) {
                LinearProgressIndicator(
                    Modifier.fillMaxWidth(),
                    color = Cyan
                )
            }
        } else {
            val actionColor = when (report.action) {
                "BUY" -> Green
                "SELL" -> Red
                else -> Cyan
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "AI CONSENSUS",
                        color = Muted,
                        fontSize = 10.sp
                    )
                    Text(
                        report.action,
                        color = actionColor,
                        fontSize = 29.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("CONFIDENCE", color = Muted, fontSize = 10.sp)
                    Text(
                        "${report.confidence}%",
                        color = Color.White,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Metric(
                    "Directional score",
                    "%+.1f".format(report.directionalScore)
                )
                Metric(
                    "Agreement",
                    "${report.agreement}/${report.components.count { kotlin.math.abs(it.score) >= 15.0 }}"
                )
            }

            Spacer(Modifier.height(12.dp))

            report.qualityGate?.let { gate ->
                CardBox {
                    Text("AI TRADE QUALITY GATE",color=Cyan,fontSize=11.sp,fontWeight=FontWeight.Bold)
                    Text(if(gate.allowed) "ENTRY CHECKS PASSED" else "ENTRY BLOCKED — WAIT",color=if(gate.allowed) Green else Red,fontSize=15.sp,fontWeight=FontWeight.ExtraBold)
                    Text("Quality checks: ${gate.qualityScore}/100",color=Muted,fontSize=10.sp)
                    gate.blockers.forEach { Text("• $it",color=Red,fontSize=10.sp) }
                    gate.checks.forEach { Text("• $it",color=Green,fontSize=10.sp) }
                }
            }

            val regime = vm.marketRegime
            if (regime != null) {
                CardBox {
                    Text(
                        "MARKET REGIME",
                        color = Cyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        regime.regime,
                        color = when (regime.regime) {
                            "HIGH VOLATILITY" -> Red
                            "TRENDING" -> Green
                            else -> Cyan
                        },
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        "Trend: ${regime.trend}  •  Volatility: ${regime.volatility}",
                        color = Muted,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Metric("ATR", "%.2f%%".format(regime.atrPercent))
                        Metric("Volatility ratio", "%.2fx".format(regime.volatilityRatio))
                        Metric("Efficiency", "%.2f".format(regime.efficiencyRatio))
                    }
                    Text(
                        "ADX (Wilder 14): %.1f  •  Trend strength: %s".format(
                            regime.adx, regime.trendStrength
                        ),
                        color = when (regime.trendStrength) {
                            "STRONG", "VERY STRONG" -> Green
                            "DEVELOPING" -> Cyan
                            "WEAK" -> Muted
                            else -> Red
                        },
                        fontSize = 10.sp
                    )
                    Text(
                        "Heuristic confidence: %d%%".format(regime.confidence),
                        color = Muted,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Text(
                        regime.explanation,
                        color = Muted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 5.dp)
                    )
                }
            } else {
                Text("Market Regime: waiting for enough closed candles", color = Muted, fontSize = 11.sp)
            }

            HorizontalDivider(color = Muted.copy(alpha = 0.2f))
            Text(
                "ANALYSIS COMPONENTS",
                color = Cyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 10.dp, bottom = 8.dp)
            )

            report.components.forEach { component ->
                val color = when {
                    component.score > 0 -> Green
                    component.score < 0 -> Red
                    else -> Muted
                }

                Row(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            component.name,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            component.direction,
                            color = color,
                            fontSize = 9.sp
                        )
                    }
                    Text(
                        "%+.0f".format(component.score),
                        color = color,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${(component.weight * 100).toInt()}%",
                        color = Muted,
                        fontSize = 10.sp,
                        modifier = Modifier.width(36.dp)
                    )
                }

                LinearProgressIndicator(
                    progress = { (kotlin.math.abs(component.score) / 100.0).toFloat() },
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = color,
                    trackColor = Muted.copy(alpha = 0.15f)
                )
            }

            if (report.reasons.isNotEmpty()) {
                Text(
                    "DECISION REASONS",
                    color = Cyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 12.dp, bottom = 5.dp)
                )
                report.reasons.forEach {
                    Text("• $it", color = Muted, fontSize = 11.sp)
                }
            }

            if (report.warnings.isNotEmpty()) {
                Text(
                    "WARNINGS",
                    color = Red,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 12.dp, bottom = 5.dp)
                )
                report.warnings.forEach {
                    Text("• $it", color = Red.copy(alpha = 0.85f), fontSize = 10.sp)
                }
            }
        }
    }
}


@Composable fun PriceActionCard(vm: SpotViewModel) {
    val report = vm.priceActionReport
    Section("LONG-TERM PRICE ACTION", "1 year • 2 years • swing structure • Fibonacci")
    CardBox {
        if (report == null) {
            Text("Loading long-term daily / weekly / monthly price history…", color = Muted, fontSize = 11.sp)
        } else {
            val horizons = listOfNotNull(report.twoYearTrend, report.yearlyTrend, report.weeklyTrend, report.monthlyTrend)
            horizons.forEach { h ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(h.label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${h.candles} candles • ${h.structure}", color = Muted, fontSize = 9.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(h.direction, color = when(h.direction) { "BULLISH" -> Green; "BEARISH" -> Red; else -> Cyan }, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${if(h.changePercent >= 0) "+" else ""}${"%.2f".format(h.changePercent)}%", color = Color.White, fontSize = 10.sp)
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 7.dp), color = Muted.copy(alpha = .2f))
            Text("CANDLE PATTERNS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            if (report.patterns.isEmpty()) Text("No confirmed pattern on the latest closed daily candle", color = Muted, fontSize = 10.sp)
            report.patterns.forEach { p ->
                Text("${p.name} • ${p.direction} • ${p.strength}/100", color = when(p.direction) { "BULLISH" -> Green; "BEARISH" -> Red; else -> Muted }, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Text(p.explanation, color = Muted, fontSize = 9.sp)
            }
            HorizontalDivider(Modifier.padding(vertical = 7.dp), color = Muted.copy(alpha = .2f))
            Text("FIBONACCI RETRACEMENTS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(report.fibonacci.joinToString("   ") { "${(it.ratio * 100).toInt()}% ${fmt(it.price)}" }.ifBlank { "Insufficient swing range" }, color = Color.White, fontSize = 9.sp)
            Text(report.volumeConfirmation, color = if(report.volumeConfirmation.startsWith("BULLISH")) Green else if(report.volumeConfirmation.startsWith("BEARISH")) Red else Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 7.dp))
            Text(report.summary, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable fun CognitiveIntelligenceCard(vm: SpotViewModel) {
    val report = vm.cognitiveReport
    Section("ALPON COGNITIVE INTELLIGENCE", "Regime • Scenarios • Liquidity • Mistakes • Risk")
    CardBox {
        if (report == null) {
            Text("Waiting for market and analysis data…", color = Muted, fontSize = 11.sp)
        } else {
            Text("1. MARKET REGIME", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(report.regime?.let { "${it.regime} • ${it.trend} • ${it.volatility} volatility • ADX ${"%.1f".format(it.adx)}" } ?: "Insufficient closed candles", color = Color.White, fontSize = 12.sp)
            report.regime?.let { Text(it.explanation, color = Muted, fontSize = 10.sp) }
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Muted.copy(alpha = .2f))
            Text("2. THREE MARKET SCENARIOS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            report.scenarios.forEach { s ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${s.name} • ${s.bias}", color = when(s.name) { "BULLISH" -> Green; "BEARISH" -> Red; else -> Cyan }, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Evidence ${s.evidenceScore}/100", color = Muted, fontSize = 9.sp)
                    }
                    Text("Trigger: ${s.trigger}", color = Color.White, fontSize = 10.sp)
                    Text("Invalidation: ${s.invalidation}", color = Muted, fontSize = 9.sp)
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Muted.copy(alpha = .2f))
            Text("3. LIQUIDITY INTELLIGENCE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(report.liquidity.bias, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Taker buy ${report.liquidity.buyPressure?.let { "%.1f%%".format(it) } ?: "—"} • sell ${report.liquidity.sellPressure?.let { "%.1f%%".format(it) } ?: "—"} • relative volume ${report.liquidity.relativeVolume?.let { "%.2f×".format(it) } ?: "—"}", color = Muted, fontSize = 10.sp)
            Text("Nearest pool: ${report.liquidity.nearestPool}", color = Color.White, fontSize = 10.sp)
            Text(report.liquidity.warning, color = Muted, fontSize = 9.sp)
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Muted.copy(alpha = .2f))
            Text("4. MISTAKE INTELLIGENCE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("Closed Paper Trading outcomes: ${report.mistakes.sampleCount}", color = Color.White, fontSize = 11.sp)
            report.mistakes.lessons.forEach { Text("• $it", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp)) }
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Muted.copy(alpha = .2f))
            Text("5. SMART RISK CONTROLLER", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(report.risk.status, color = if(report.risk.allowed) Green else Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            report.risk.reasons.take(6).forEach { Text("• $it", color = Muted, fontSize = 10.sp) }
            Text(report.risk.riskNote, color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 5.dp))
            Text(report.disclaimer, color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable fun SmartMoneyCard(vm: SpotViewModel) {
    val report = vm.smartMoneyReport
    Section("SMART MONEY & LIQUIDITY", "Order Blocks • Equal High/Low • Breakout quality")
    CardBox {
        if (report == null) {
            Text("Waiting for at least 60 closed candles…", color = Muted, fontSize = 11.sp)
        } else {
            Text("${report.bias} • ${report.score.toInt()}/100", color = when(report.bias) { "BULLISH" -> Green; "BEARISH" -> Red; else -> Cyan }, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(report.breakoutQuality.replace('_', ' '), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            Text(report.explanation, color = Muted, fontSize = 10.sp)
            HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Muted.copy(alpha = .2f))
            Text("ACTIVE ORDER BLOCKS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            if (report.orderBlocks.isEmpty()) Text("No unmitigated order block found", color = Muted, fontSize = 10.sp)
            report.orderBlocks.takeLast(5).forEach { zone ->
                Text("${zone.direction} • ${fmt(zone.low)} – ${fmt(zone.high)} • strength ${zone.strength}", color = if(zone.direction == "BULLISH") Green else Red, fontSize = 9.sp)
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Muted.copy(alpha = .2f))
            Text("LIQUIDITY POOLS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            if (report.liquidityPools.isEmpty()) Text("No equal-high / equal-low pool confirmed", color = Muted, fontSize = 10.sp)
            report.liquidityPools.take(6).forEach { pool ->
                Text("${pool.type.replace('_', ' ')} • ${fmt(pool.price)} • ${pool.touches} touches${if(pool.swept) " • SWEPT" else ""}", color = if(pool.swept) Cyan else Color.White, fontSize = 9.sp)
            }
        }
    }
}

@Composable fun MultiTimeframeCard(vm: SpotViewModel) {
    val m = vm.multiTimeframeSignal

    Section("MULTI-TIMEFRAME AI", "12 Binance timeframes • 1M to 5M")
    CardBox {
        if (m == null) {
            Text(
                vm.multiTimeframeError ?: "Loading 12 timeframe analysis...",
                color = Muted,
                fontSize = 12.sp
            )
            if (vm.loading) LinearProgressIndicator(
                Modifier.fillMaxWidth(),
                color = Cyan
            )
        } else {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    m.action,
                    color = when (m.action) {
                        "BUY" -> Green
                        "SELL" -> Red
                        else -> Cyan
                    },
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    "${m.score}/100",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text("${m.trend} • ${m.alignment}", color = Muted, fontSize = 11.sp)
            HorizontalDivider(
                Modifier.padding(vertical = 10.dp),
                color = Muted.copy(alpha = .2f)
            )

            m.readings.forEach { r ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(r.label, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(
                        r.direction,
                        color = when (r.direction) {
                            "BULLISH" -> Green
                            "BEARISH" -> Red
                            else -> Muted
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1.4f)
                    )
                    Text("${r.score}/100", color = Cyan, fontSize = 11.sp)
                }
            }

            HorizontalDivider(
                Modifier.padding(vertical = 10.dp),
                color = Muted.copy(alpha = .2f)
            )
            Text("POTENTIAL HOLDING WINDOW", color = Muted, fontSize = 10.sp)
            Text(m.holdingWindow, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

            if (m.action != "WAIT") {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("Entry", fmt(m.entry))
                    Metric("Stop loss", fmt(m.stop))
                    Metric("TP 1", fmt(m.tp1))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Metric("TP 2", fmt(m.tp2))
                    Metric("TP 3", fmt(m.tp3))
                }
            }

            HorizontalDivider(
                Modifier.padding(vertical = 10.dp),
                color = Muted.copy(alpha = .2f)
            )
            Text(m.explanation, color = Muted, fontSize = 11.sp)
            Text(
                "Heuristic analysis, not a probability or guaranteed forecast. Holding time is an estimate.",
                color = Cyan,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable fun Metric(label:String,value:String){Column{Text(label,color=Muted,fontSize=10.sp);Text(value,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}
private fun emaSeries(values:List<Double>,period:Int):List<Double>{
    if(values.isEmpty())return emptyList();val alpha=2.0/(period+1.0);var e=values.first()
    return values.mapIndexed{i,v->if(i==0)e=v else e=alpha*v+(1-alpha)*e;e}
}
data class ChartLayers(val ema9:Boolean=true,val ema21:Boolean=true,val ema50:Boolean=true,val ema200:Boolean=true,val bands:Boolean=true,val vwap:Boolean=true)
@Composable fun PremiumChartCard(vm:SpotViewModel){
    var fullscreen by remember{mutableStateOf(false)}
    var layers by remember{mutableStateOf(ChartLayers())}
    val data=vm.candles
    val chartHeight=(androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp * 0.70f).coerceIn(230.dp,340.dp)
    CardBox {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Column { Text("LIVE BINANCE CHART",color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp);Text("${vm.symbol} • ${vm.interval} • ${vm.liveStatus}",color=if(vm.liveStatus=="LIVE")Green else Muted,fontSize=10.sp) }
            Row { IconButton(onClick={vm.load()}){Icon(Icons.Default.Refresh,null,tint=Cyan)};IconButton(onClick={fullscreen=true}){Icon(Icons.Default.Fullscreen,null,tint=Cyan)} }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)){
            listOf("1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w","1M").forEach{tf->FilterChip(selected=vm.interval==tf,onClick={vm.changeInterval(tf)},label={Text(tf,fontSize=10.sp)})}
            FilterChip(selected=vm.interval=="1d",onClick={vm.changeInterval("1d")},label={Text("2Y DAILY",fontSize=10.sp)})
        }
        Spacer(Modifier.height(8.dp))
        if(data.isNotEmpty()) InteractiveCandleChart(data,layers,Modifier.fillMaxWidth().height(chartHeight),vm.marketStructure,vm.priceActionReport,vm.smartMoneyReport) else Box(Modifier.fillMaxWidth().height(230.dp),contentAlignment=Alignment.Center){Text(if(vm.loading)"Loading Binance candles…" else "Chart data unavailable",color=Muted)}
        HistoryLoadControl(vm)
        HistoryStatsCard(vm)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            @Composable fun layerChip(label:String,active:Boolean,onClick:()->Unit){FilterChip(selected=active,onClick=onClick,label={Text(label,fontSize=9.sp)})}
            layerChip("EMA 9",layers.ema9){layers=layers.copy(ema9=!layers.ema9)};layerChip("EMA 21",layers.ema21){layers=layers.copy(ema21=!layers.ema21)};layerChip("EMA 50",layers.ema50){layers=layers.copy(ema50=!layers.ema50)};layerChip("EMA 200",layers.ema200){layers=layers.copy(ema200=!layers.ema200)};layerChip("Bollinger",layers.bands){layers=layers.copy(bands=!layers.bands)};layerChip("VWAP",layers.vwap){layers=layers.copy(vwap=!layers.vwap)}
        }
        val closes=data.map{it.close};val last=closes.lastOrNull()
        val rsi=vm.signal?.rsi
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("RSI",rsi?.let{"%.1f".format(it)}?:"—");Metric("MACD",vm.signal?.macd?.let{"%.5f".format(it)}?:"—");Metric("EMA 9",emaSeries(closes,9).lastOrNull()?.let{fmt(it)}?:"—");Metric("Last",last?.let{fmt(it)}?:"—")}
        Text("Pinch to zoom • Drag to move • Green = bullish / Red = bearish",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=6.dp))
    }
    if(fullscreen) Dialog(onDismissRequest={fullscreen=false},properties=DialogProperties(usePlatformDefaultWidth=false,decorFitsSystemWindows=false)){
        Surface(Modifier.fillMaxSize(),color=Bg){Column(Modifier.fillMaxSize().padding(12.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text(vm.symbol,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("FULL SCREEN • BINANCE SPOT • ${vm.liveStatus}",color=Muted,fontSize=10.sp)};IconButton(onClick={fullscreen=false}){Icon(Icons.Default.Close,"Close",tint=Cyan)}}
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w","1M").forEach{tf->FilterChip(selected=vm.interval==tf,onClick={vm.changeInterval(tf)},label={Text(tf)})};FilterChip(selected=vm.interval=="1d",onClick={vm.changeInterval("1d")},label={Text("2Y DAILY")})}
            if(data.isNotEmpty()) InteractiveCandleChart(data,layers,Modifier.fillMaxWidth().weight(1f).padding(vertical=8.dp),vm.marketStructure,vm.priceActionReport,vm.smartMoneyReport) else Box(Modifier.weight(1f),contentAlignment=Alignment.Center){Text("Waiting for Binance stream…",color=Muted)}
            HistoryLoadControl(vm)
            HistoryStatsCard(vm)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("EMA 9" to layers.ema9,"EMA 21" to layers.ema21,"EMA 50" to layers.ema50,"EMA 200" to layers.ema200,"Bollinger" to layers.bands,"VWAP" to layers.vwap).forEach{(name,on)->FilterChip(selected=on,onClick={layers=when(name){"EMA 9"->layers.copy(ema9=!layers.ema9);"EMA 21"->layers.copy(ema21=!layers.ema21);"EMA 50"->layers.copy(ema50=!layers.ema50);"EMA 200"->layers.copy(ema200=!layers.ema200);"Bollinger"->layers.copy(bands=!layers.bands);else->layers.copy(vwap=!layers.vwap)}},label={Text(name,fontSize=10.sp)})}}
            Text("Live trade ticks update the current candle in real time. EMA, Bollinger Bands, VWAP and volume are overlaid; RSI and MACD are shown in the analysis panel. Signals update only after a candle closes.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(vertical=10.dp))
        }}
    }
}

@Composable fun HistoryLoadControl(vm:SpotViewModel){
    Column(
        Modifier.fillMaxWidth().padding(vertical=6.dp),
        horizontalAlignment=Alignment.CenterHorizontally
    ){
        Text(
            when {
                vm.historyLoading -> "LOADING OLDER BINANCE CANDLES..."
                vm.historyExhausted -> "EARLIEST AVAILABLE HISTORY LOADED"
                else -> "↓ LOAD 1,000 OLDER CANDLES"
            },
            color=if(vm.historyExhausted) Muted else Cyan,
            fontSize=11.sp,
            fontWeight=FontWeight.Bold,
            modifier=Modifier
                .clickable(enabled=!vm.historyLoading && !vm.historyExhausted){
                    vm.loadOlderHistory()
                }
                .padding(10.dp)
        )

        Text(
            when {
                vm.fullHistoryLoading ->
                    "DOWNLOADING FULL HISTORY • ${vm.fullHistoryDownloaded} NEW CANDLES"
                else -> "↓ DOWNLOAD FULL BINANCE HISTORY"
            },
            color=if(vm.fullHistoryLoading) Muted else Green,
            fontSize=11.sp,
            fontWeight=FontWeight.Bold,
            modifier=Modifier
                .clickable(enabled=!vm.fullHistoryLoading && !vm.loading){
                    vm.downloadFullHistory()
                }
                .padding(10.dp)
        )

        if(vm.fullHistoryDownloaded > 0){
            Text(
                "Downloaded: ${vm.fullHistoryDownloaded} candles • ${vm.symbol} • ${vm.interval}",
                color=Muted,
                fontSize=10.sp
            )
        }

        vm.fullHistoryError?.let { message ->
            Text(
                message,
                color=Red,
                fontSize=10.sp,
                modifier=Modifier.padding(horizontal=8.dp, vertical=4.dp)
            )
        }
    }
}

@Composable fun HistoryStatsCard(vm: SpotViewModel){
    LaunchedEffect(vm.symbol, vm.interval){
        vm.refreshHistoryStats()
    }

    val firstDate = vm.historyEarliestTime?.let {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            .format(java.util.Date(it))
    } ?: "—"

    val lastDate = vm.historyLatestTime?.let {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            .format(java.util.Date(it))
    } ?: "—"

    Column(
        Modifier.fillMaxWidth().padding(vertical = 8.dp)
    ){
        HorizontalDivider(color = Muted.copy(alpha = .25f))
        Text(
            "SAVED BINANCE HISTORY",
            color = Cyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 9.dp, bottom = 8.dp)
        )
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ){
            Column {
                Text("TOTAL CANDLES", color = Muted, fontSize = 9.sp)
                Text(
                    "%,d".format(java.util.Locale.US, vm.historyStoredCount),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Column {
                Text("FIRST CANDLE", color = Muted, fontSize = 9.sp)
                Text(firstDate, color = Color.White, fontSize = 12.sp)
            }
            Column {
                Text("LATEST CANDLE", color = Muted, fontSize = 9.sp)
                Text(lastDate, color = Color.White, fontSize = 12.sp)
            }
        }
        Text(
            "${vm.symbol} • ${vm.interval} • Stored locally",
            color = Muted,
            fontSize = 9.sp,
            modifier = Modifier.padding(top = 7.dp)
        )
    }
}

@Composable fun InteractiveCandleChart(c:List<Candle>,layers:ChartLayers,modifier:Modifier=Modifier,structure:MarketStructureReport?=null,priceAction:PriceActionReport?=null,smartMoney:SmartMoneyReport?=null){
    var zoom by remember{mutableFloatStateOf(1f)};var pan by remember{mutableFloatStateOf(0f)}
    Canvas(modifier.background(Color(0xFF091321),RoundedCornerShape(12.dp)).pointerInput(Unit){detectTransformGestures{_,panChange,zoomChange,_->zoom=(zoom*zoomChange).coerceIn(1f,4f);pan=(pan+panChange.x).coerceIn(-4000f,4000f)}}){
        val all=c;if(all.isEmpty())return@Canvas
        val count=(all.size/zoom).toInt().coerceAtLeast(12).coerceAtMost(all.size)
        val maxStart=(all.size-count).coerceAtLeast(0)
        val shift=(maxStart+(-pan/(size.width.coerceAtLeast(1f))*count).toInt()).coerceIn(0,maxStart)
        val data=all.drop(shift).take(count)
        val priceLo=data.minOf{it.low};val priceHi=data.maxOf{it.high};val range=(priceHi-priceLo).coerceAtLeast(kotlin.math.abs(priceHi)*0.000001).coerceAtLeast(1e-10);val topPad=size.height*.08f;val chartBottom=size.height*.78f;val step=size.width/data.size
        val y:(Double)->Float={v->chartBottom-((v-priceLo)/range*(chartBottom-topPad)).toFloat()}
        for(i in 0..5){val yy=topPad+(chartBottom-topPad)*i/5f;drawLine(Muted.copy(alpha=.17f),Offset(0f,yy),Offset(size.width,yy),1f)}
        val maxVol=data.maxOf{it.volume}.coerceAtLeast(1.0)
        data.forEachIndexed{i,v->val x=step*(i+.5f);val color=if(v.close>=v.open)Green else Red;drawLine(color,Offset(x,y(v.high)),Offset(x,y(v.low)),1.4f);val bodyTop=y(maxOf(v.open,v.close));val bodyBottom=y(minOf(v.open,v.close));drawLine(color.copy(alpha=.9f),Offset(x,bodyTop),Offset(x,bodyBottom.coerceAtLeast(bodyTop+2f)),(step*.62f).coerceAtLeast(2f),StrokeCap.Square);val vh=(v.volume/maxVol*size.height*.16f).toFloat();drawLine(color.copy(alpha=.4f),Offset(x,size.height-2f),Offset(x,size.height-vh), (step*.55f).coerceAtLeast(1f))}
        // Shared time mapping for all market-structure and Smart Money overlays.
        val firstTime = data.first().time
        val lastTime = data.last().time
        val duration = (lastTime-firstTime).toDouble().coerceAtLeast(1.0)
        fun xAt(time:Long):Float =
            step*.5f + ((time-firstTime).toDouble()/duration).toFloat()*(size.width-step)
        // Market structure overlays: support/resistance, trendlines and FVG.
        structure?.let { report ->
            report.support.forEach { level ->
                if (level.price in priceLo..priceHi) {
                    val yy = y(level.price)
                    drawLine(Color(0xFF26D98A).copy(alpha=.72f), Offset(0f,yy), Offset(size.width,yy), 1.5f)
                }
            }
            report.resistance.forEach { level ->
                if (level.price in priceLo..priceHi) {
                    val yy = y(level.price)
                    drawLine(Color(0xFFFF647C).copy(alpha=.72f), Offset(0f,yy), Offset(size.width,yy), 1.5f)
                }
            }
            report.swingPoints.filter { it.time in firstTime..lastTime }.forEach { swing ->
                val x=xAt(swing.time)
                val color=if(swing.type=="LOW") Color(0xFF26D98A) else Color(0xFFFF647C)
                drawCircle(color.copy(alpha=.9f),radius=2.8f,center=Offset(x,y(swing.price)))
            }
            report.trendLines.forEach { line ->
                val x1=xAt(line.startTime)
                val x2=xAt(lastTime)
                val projectedPrice = line.priceAt(lastTime)
                val color=if(line.type.contains("SUPPORT",true) || line.type.contains("BULL",true))
                    Color(0xFF26D98A) else Color(0xFFFF647C)
                if (projectedPrice.isFinite() && projectedPrice > 0.0) {
                    drawLine(color.copy(alpha=.9f),Offset(x1,y(line.startPrice)),Offset(x2,y(projectedPrice)),2f)
                }
            }
            report.fairValueGaps.forEach { gap ->
                if(gap.time in firstTime..lastTime && gap.high>=priceLo && gap.low<=priceHi) {
                    val left=xAt(gap.time).coerceIn(0f,size.width)
                    val right=(left+step*5f).coerceAtMost(size.width)
                    val top=y(gap.high).coerceIn(topPad,chartBottom)
                    val bottom=y(gap.low).coerceIn(topPad,chartBottom)
                    val color=if(gap.type.contains("BULL",true)) Color(0xFF26D98A) else Color(0xFFFF647C)
                    if(right>left && bottom>top) {
                        drawRect(color.copy(alpha=.13f),Offset(left,top),
                            androidx.compose.ui.geometry.Size(right-left,bottom-top))
                    }
                }
            }
        }
        smartMoney?.orderBlocks?.forEach { zone ->
            if (zone.high >= priceLo && zone.low <= priceHi) {
                val left = if (zone.originTime in firstTime..lastTime) xAt(zone.originTime).coerceIn(0f, size.width) else 0f
                val top = y(zone.high).coerceIn(topPad, chartBottom)
                val bottom = y(zone.low).coerceIn(topPad, chartBottom)
                val color = if (zone.direction == "BULLISH") Color(0xFF20D69A) else Color(0xFFFF647C)
                if (bottom > top && size.width > left) drawRect(color.copy(alpha = .10f), Offset(left, top), androidx.compose.ui.geometry.Size(size.width-left, bottom-top))
            }
        }
        smartMoney?.liquidityPools?.forEach { pool ->
            if (pool.price in priceLo..priceHi) {
                val yy = y(pool.price)
                val color = if (pool.type == "BUY_SIDE") Color(0xFFFFB74D) else Color(0xFF4DD0E1)
                drawLine(color.copy(alpha = if(pool.swept) .95f else .45f), Offset(0f, yy), Offset(size.width, yy), if(pool.swept) 1.8f else 1f)
            }
        }
        priceAction?.fibonacci?.forEach { level ->
            if(level.price in priceLo..priceHi) {
                val yy=y(level.price)
                drawLine(Color(0xFFB388FF).copy(alpha=.62f),Offset(0f,yy),Offset(size.width,yy),1f)
            }
        }
        val closes=data.map{it.close}
        fun drawLineSeries(values:List<Double>,color:Color,width:Float=1.8f){if(values.size<2)return;val path=Path();values.forEachIndexed{i,v->val x=step*(i+.5f);if(i==0)path.moveTo(x,y(v))else path.lineTo(x,y(v))};drawPath(path,color= color,style=androidx.compose.ui.graphics.drawscope.Stroke(width=width))}
        if(layers.ema9)drawLineSeries(emaSeries(closes,9),Color(0xFFFFD166),1.8f)
        if(layers.ema21)drawLineSeries(emaSeries(closes,21),Color(0xFF4DD0E1),1.8f)
        if(layers.ema50)drawLineSeries(emaSeries(closes,50),Color(0xFFB388FF),1.8f)
        if(layers.ema200)drawLineSeries(emaSeries(closes,200),Color(0xFFFF8A65),2f)
        if(layers.bands && closes.size>=20){val mid=closes.indices.map{i->if(i<19)closes.take(i+1).average() else closes.subList(i-19,i+1).average()};val upper=mid.indices.map{i->val part=closes.subList((i-19).coerceAtLeast(0),i+1);val avg=part.average();avg+2*kotlin.math.sqrt(part.map{(it-avg)*(it-avg)}.average())};val lower=mid.indices.map{i->val part=closes.subList((i-19).coerceAtLeast(0),i+1);val avg=part.average();avg-2*kotlin.math.sqrt(part.map{(it-avg)*(it-avg)}.average())};drawLineSeries(upper,Color(0xFF78909C),1f);drawLineSeries(lower,Color(0xFF78909C),1f)}
        if(layers.vwap){var pv=0.0;var vol=0.0;val series=data.map{v->val typical=(v.high+v.low+v.close)/3.0;pv+=typical*v.volume;vol+=v.volume;(pv/vol.coerceAtLeast(1e-12))};drawLineSeries(series,Color(0xFFFFFFFF),1.5f)}
        val lastPrice=data.last().close;val lastY=y(lastPrice);drawLine(Cyan.copy(alpha=.75f),Offset(0f,lastY),Offset(size.width,lastY),1.2f)
    }
}
@Composable fun CandleChart(c:List<Candle>,structure:MarketStructureReport?=null,priceAction:PriceActionReport?=null,smartMoney:SmartMoneyReport?=null){InteractiveCandleChart(c,ChartLayers(),Modifier.fillMaxWidth().height(205.dp),structure,priceAction,smartMoney)}
@Composable fun NewsScreen(vm: SpotViewModel) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(top=2.dp,bottom=10.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Column { Text("CRYPTO NEWS", color=Color.White, fontSize=19.sp, fontWeight=FontWeight.ExtraBold); Text("Latest headlines • Last 24 hours", color=Muted, fontSize=11.sp) }
            IconButton(onClick={vm.loadNews()}, enabled=!vm.newsLoading) { Icon(Icons.Default.Refresh, "Refresh news", tint=Cyan) }
        }
        Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.padding(bottom=10.dp)) {
            listOf("Yahoo Finance", "CoinMarketCap").forEach { source ->
                Text(source, color=Cyan, fontSize=10.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(end=8.dp).background(Blue.copy(alpha=.12f),RoundedCornerShape(20.dp)).padding(horizontal=10.dp, vertical=6.dp))
            }
            Spacer(Modifier.weight(1f)); Text("AUTO • 5 MIN", color=Muted, fontSize=9.sp)
        }
        if(vm.newsLoading && vm.news.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){CircularProgressIndicator(color=Cyan)}
        else if(vm.news.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Newspaper,null,tint=Cyan,modifier=Modifier.size(38.dp));Spacer(Modifier.height(10.dp));Text(vm.newsError?:"No recent headlines available",color=Muted,fontSize=12.sp);Spacer(Modifier.height(8.dp));Button(onClick={vm.loadNews()},colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("Try again")}}}
        else LazyColumn(contentPadding=PaddingValues(bottom=18.dp), verticalArrangement=Arrangement.spacedBy(2.dp)) {
            items(vm.news, key={it.url}) { item ->
                CardBox {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                        Text(item.source.uppercase(),color=Cyan,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                        Text(relativeNewsTime(item.publishedAt),color=Muted,fontSize=10.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                    Text(item.title,color=Color.White,fontSize=15.sp,fontWeight=FontWeight.Bold,lineHeight=20.sp)
                    if(item.summary.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(item.summary,color=Muted,fontSize=11.sp,lineHeight=16.sp,maxLines=4) }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End) {
                        Text("READ FULL STORY  ↗",color=Blue,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.clickable { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.url))) } }.padding(6.dp))
                    }
                }
            }
        }
        if(vm.newsLoading && vm.news.isNotEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth(),color=Cyan)
        vm.newsError?.takeIf{vm.news.isNotEmpty()}?.let { Text(it,color=Muted,fontSize=10.sp,modifier=Modifier.padding(bottom=8.dp)) }
        Text("Headlines are provided by their publishers. News may be delayed; verify important information at the original source.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(bottom=8.dp))
    }
}

private fun relativeNewsTime(timestamp: Long): String {
    val minutes=((System.currentTimeMillis()-timestamp).coerceAtLeast(0L)/60_000L)
    return when { minutes<1 -> "Just now"; minutes<60 -> "${minutes}m ago"; minutes<1440 -> "${minutes/60}h ago"; else -> "${minutes/1440}d ago" }
}

@Composable fun MarketsScreen(vm:SpotViewModel,onOpen:()->Unit){var query by remember{mutableStateOf("")};Column{OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),placeholder={Text("Search trading pair")},singleLine=true);Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("TOP SPOT MARKETS",color=Color.White,fontWeight=FontWeight.Bold);Text("24h change",color=Muted,fontSize=11.sp)};LazyColumn{items(vm.markets.filter{it.symbol.contains(query.uppercase())}){t->Row(Modifier.fillMaxWidth().clickable{vm.select(t.symbol);onOpen()}.padding(vertical=12.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text(t.symbol,color=Color.White,fontWeight=FontWeight.Bold);Text("Vol ${compact(t.quoteVolume.toDoubleOrNull()?:0.0)} USDT",color=Muted,fontSize=10.sp)};Column(horizontalAlignment=Alignment.End){Text(fmt(t.lastPrice.toDoubleOrNull()?:0.0),color=Color.White);val ch=t.priceChangePercent.toDoubleOrNull()?:0.0;Text("${if(ch>0)"+" else ""}${"%.2f".format(ch)}%",color=if(ch>=0)Green else Red,fontSize=12.sp)}};HorizontalDivider(color=Muted.copy(alpha=.15f))}}}}
@Composable fun ScannerScreen(vm:SpotViewModel,onOpen:()->Unit){
    var lowerTab by remember { mutableStateOf("Chart") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Column { Text("LIVE MARKET SCANNER",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=17.sp); Text("Binance Spot • Live market feed",color=Muted,fontSize=10.sp) }
            IconButton(onClick={vm.load();vm.scan()}) { Icon(Icons.Default.Refresh,null,tint=Cyan) }
        }
        CardBox {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                Column { Text("SELECTED PAIR",color=Muted,fontSize=9.sp,letterSpacing=1.sp); Text(vm.symbol,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.ExtraBold) }
                val t=vm.ticker
                Column(horizontalAlignment=Alignment.End){ Text(t?.lastPrice?.toDoubleOrNull()?.let{fmt(it)}?:"—",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold); val ch=t?.priceChangePercent?.toDoubleOrNull()?:0.0; Text("${if(ch>=0)"+" else ""}${"%.2f".format(ch)}%",color=if(ch>=0)Green else Red,fontSize=12.sp,fontWeight=FontWeight.Bold) }
            }
            Spacer(Modifier.height(10.dp))
            MarketPairPicker(vm)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w","1M").forEach { tf -> FilterChip(selected=vm.scanInterval==tf,onClick={vm.changeScanInterval(tf)},label={Text(tf,fontSize=10.sp)}) } }
            Box(Modifier.fillMaxWidth().height(224.dp).background(Color(0xFF091321),RoundedCornerShape(14.dp)).padding(8.dp),contentAlignment=Alignment.Center){
                if(vm.candles.isNotEmpty()) CandleChart(vm.candles,vm.marketStructure,vm.priceActionReport,vm.smartMoneyReport) else Text(if(vm.loading)"Loading live Binance candles…" else "Chart data unavailable",color=Muted,fontSize=12.sp)
            }
            Spacer(Modifier.height(10.dp))
            // Three-position control: chart is intentionally the first/default view.
            Row(Modifier.fillMaxWidth().background(Color(0xFF091321),RoundedCornerShape(14.dp)).padding(4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                listOf("Chart","Analysis","Scanner").forEach { label ->
                    Box(Modifier.weight(1f).background(if(lowerTab==label)Brush.horizontalGradient(listOf(Blue,Cyan)) else Brush.horizontalGradient(listOf(Color.Transparent,Color.Transparent)),RoundedCornerShape(10.dp)).clickable{lowerTab=label}.padding(vertical=9.dp),contentAlignment=Alignment.Center){Text(label,color=if(lowerTab==label)Color(0xFF06111E) else Muted,fontSize=11.sp,fontWeight=FontWeight.Bold)}
                }
            }
        }
        when(lowerTab){
            "Chart" -> { Section("LIVE CANDLESTICK CHART","Green / red candles"); Text("Candles and prices are loaded from Binance Spot. Tap a market below to switch the chart.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(bottom=8.dp)) }
            "Analysis" -> {
                val a=vm.signal
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Section("TRADE PLAN & RISK CONTROL",vm.aiAnalysisReport?.action ?: a?.action ?: "UNAVAILABLE")
                    if(a==null) Text("Analysis unavailable until enough verified Binance candles are received.",color=Muted,fontSize=11.sp)
                    else {
                        val gatedAction = when (vm.aiAnalysisReport?.action) {
                            "BUY" -> if (a.action == "BUY") "BUY" else "WAIT"
                            "SELL" -> "SELL"
                            else -> "WAIT"
                        }
                        var capital by remember { mutableStateOf("1000") }
                        var riskPct by remember { mutableStateOf("0.5") }
                        val balance=capital.toDoubleOrNull()?.takeIf{it>0}
                        val riskPercent=riskPct.toDoubleOrNull()?.takeIf{it>0&&it<=100}
                        val riskCash=if(balance!=null&&riskPercent!=null)balance*riskPercent/100.0 else null
                        val riskPlan = RiskManagementEngine.calculate(
                            action=gatedAction,
                            entry=a.entry,
                            atr=a.atr,
                            support=a.support,
                            resistance=a.resistance,
                            volatilityRatio=vm.marketRegime?.volatilityRatio ?: 1.0,
                            accountBalance=balance,
                            riskPercent=riskPercent,
                            maxCapitalPercent=25.0,
                            feeRate=0.001,
                            slippageRate=0.0005
                        )
                        val quantity=riskPlan?.quantity
                        CardBox {
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                                Text(gatedAction,color=when(gatedAction){"BUY"->Green;"SELL"->Red;else->Cyan},fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
                                Text("Confidence ${a.score}/100",color=Color.White,fontWeight=FontWeight.Bold)
                            }
                            Text("${a.trend} • ${a.bullishVotes} bullish / ${a.bearishVotes} bearish / ${a.neutralVotes} neutral",color=Muted,fontSize=11.sp)
                            HorizontalDivider(Modifier.padding(vertical=10.dp),color=Muted.copy(alpha=.2f))
                            Text("TRADE LEVELS",color=Cyan,fontWeight=FontWeight.Bold,fontSize=11.sp)
                            if (gatedAction == "BUY") {
                                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Entry",fmt(a.entry));Metric("Stop loss",fmt(a.stop));Metric("Risk / reward","1:${a.rr}")}
                                Spacer(Modifier.height(12.dp))
                                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Take profit 1",fmt(a.tp1));Metric("Take profit 2",fmt(a.tp2));Metric("Take profit 3",fmt(a.tp3))}
                            } else {
                                Text(
                                    if (gatedAction == "SELL") "SELL: exit or reduce an existing Binance Spot holding. No short position is opened."
                                    else "WAIT: no trade levels. Wait for a clearer market signal.",
                                    color=Muted,fontSize=11.sp
                                )
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("${a.entryTiming}",color=Color.White,fontSize=12.sp)
                            Text(a.holdingWindow,color=Cyan,fontSize=11.sp,modifier=Modifier.padding(top=6.dp))
                            Text(a.candleCloseAt,color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=4.dp))
                        }
                        CardBox {
                            Text("MONEY MANAGEMENT",color=Cyan,fontWeight=FontWeight.Bold,fontSize=13.sp)
                            Text("Set your own account balance and maximum risk per trade. These values stay on this device only.",color=Muted,fontSize=10.sp)
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(capital,{capital=it},Modifier.weight(1f),label={Text("Account (USDT)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                                OutlinedTextField(riskPct,{riskPct=it},Modifier.weight(1f),label={Text("Risk (%)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Risk amount",if(gatedAction=="BUY") riskCash?.let{fmt(it)+" USDT"}?:"—" else "—");Metric("Position size",quantity?.let{fmt(it)+" units"}?:"—")}
                            Text(quantity?.let{"Estimated notional: ${fmt(it*a.entry)} USDT"}?:"Enter a valid balance and risk percentage to calculate position size.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=7.dp))
                            Text("Default risk: 0.5% per trade • Max allocation: 25% • Fee and slippage estimates included. Gaps, liquidity and execution failures can still increase losses.",color=Red,fontSize=10.sp,modifier=Modifier.padding(top=8.dp))
                        }
                        CardBox {
                            Text("100+ TECHNICAL CHECKS",color=Cyan,fontWeight=FontWeight.Bold,fontSize=13.sp)
                            Text("${a.indicators.size} calculated readings • ${a.indicators.map{it.group}.distinct().size} analysis groups",color=Muted,fontSize=10.sp)
                            a.indicators.forEach { item ->
                                Row(Modifier.fillMaxWidth().padding(vertical=4.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                                    Column(Modifier.weight(1f)){Text(item.name,color=Color.White,fontSize=10.sp);Text(item.group,color=Muted,fontSize=9.sp)}
                                    Text(item.value,color=Color.White,fontSize=10.sp)
                                    Text(when(item.bias){1->"BULL";-1->"BEAR";else->"NEUTRAL"},color=when(item.bias){1->Green;-1->Red;else->Muted},fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.width(58.dp))
                                }
                                HorizontalDivider(color=Muted.copy(alpha=.12f))
                            }
                        }
                        Text(a.explanation,color=Muted,fontSize=10.sp,modifier=Modifier.padding(bottom=12.dp))
                    }
                }
            }
            else -> {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("SCAN OPPORTUNITIES",color=Color.White,fontWeight=FontWeight.Bold,fontSize=15.sp); Button(onClick={vm.scan()},enabled=!vm.scanning,contentPadding=PaddingValues(horizontal=10.dp,vertical=4.dp)){Text(if(vm.scanning)"Scanning…" else "Scan",fontSize=10.sp)}}
                if(vm.scanning) LinearProgressIndicator(Modifier.fillMaxWidth(),color=Cyan)
                if(!vm.scanning && vm.scanRows.isEmpty()) Text("No qualified opportunities yet. Run a scan to refresh.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(vertical=8.dp))
                LazyColumn(Modifier.weight(1f).padding(top=4.dp)) { items(vm.scanRows) { r ->
                    CardBox { Row(Modifier.fillMaxWidth().clickable { vm.select(r.symbol);lowerTab="Chart" },horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){ Column { Text(r.symbol,color=Color.White,fontWeight=FontWeight.Bold);Text(fmt(r.price),color=Muted,fontSize=11.sp) };Column(horizontalAlignment=Alignment.End){Text(r.signal.action,color=if(r.signal.action=="BUY")Green else Red,fontWeight=FontWeight.Bold);Text("Score ${r.signal.score} • ${"%.2f".format(r.change)}%",color=Muted,fontSize=10.sp)} } }
                } }
            }
        }
        if(vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth(),color=Cyan)
        vm.error?.let { Text(it,color=Red,fontSize=10.sp,modifier=Modifier.padding(top=4.dp,bottom=6.dp)) }
    }
}
@Composable fun PortfolioScreen(vm:SpotViewModel) {
    var show by remember { mutableStateOf(false) }
    val realizedPnl=vm.paperTrades.sumOf { it.pnl }
    val wins=vm.paperTrades.count { it.pnl>0.0 }
    val losses=vm.paperTrades.count { it.pnl<0.0 }
    val openValue=vm.paperPositions.sumOf { it.invested }
    var sym by remember { mutableStateOf("BTCUSDT") }
    var qty by remember { mutableStateOf("") }
    var avg by remember { mutableStateOf("") }
    val total = vm.holdings.sumOf { (vm.currentPrice(it.symbol) ?: 0.0) * it.quantity }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section("FUNDS & PERFORMANCE","PAPER ACCOUNT")
        CardBox {
            Text("AVAILABLE VIRTUAL BALANCE",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)
            Text("${fmt(vm.paperBalance)} USDT",color=Color.White,fontSize=28.sp,fontWeight=FontWeight.ExtraBold)
            Text("Open exposure: ${fmt(openValue)} USDT",color=Muted,fontSize=11.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Metric("REALIZED P/L", "${if(realizedPnl>=0) "+" else ""}${fmt(realizedPnl)}")
                Metric("WIN / LOSS", "$wins / $losses")
                Metric("OPEN", "${vm.paperPositions.size}")
            }
            Text("Simulation account • 0.1% fee per side • No real money used",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=8.dp))
        }
        Section("OPEN TRADES","${vm.paperPositions.size} ACTIVE")
        CardBox {
            if(vm.paperPositions.isEmpty()) Text("No open trades",color=Muted,fontSize=12.sp)
            else vm.paperPositions.forEach { pos ->
                Column(Modifier.fillMaxWidth().padding(vertical=6.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(pos.symbol,color=Color.White,fontWeight=FontWeight.Bold)
                        Text("OPEN",color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold)
                    }
                    Text("Opened: ${if(pos.entryTime>0) java.text.SimpleDateFormat("dd MMM yyyy, HH:mm",java.util.Locale.getDefault()).format(java.util.Date(pos.entryTime)) else "Time unavailable"}",color=Muted,fontSize=10.sp)
                    Text("Entry ${fmt(pos.entryPrice)} • Size ${fmt(pos.invested)} USDT",color=Muted,fontSize=10.sp)
                }
                HorizontalDivider(color=Muted.copy(alpha=.18f))
            }
        }
        Section("TRADE JOURNAL","${vm.paperTrades.size} CLOSED")
        CardBox {
            if(vm.paperTrades.isEmpty()) Text("Closed trades and their results will appear here.",color=Muted,fontSize=12.sp)
            else vm.paperTrades.takeLast(50).asReversed().forEach { trade ->
                Column(Modifier.fillMaxWidth().padding(vertical=7.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(trade.symbol,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)
                        Text("${if(trade.pnl>=0) "+" else ""}${fmt(trade.pnl)} USDT",color=if(trade.pnl>=0)Green else Red,fontSize=12.sp,fontWeight=FontWeight.Bold)
                    }
                    Text("Opened: ${if(trade.entryTime>0) java.text.SimpleDateFormat("dd MMM, HH:mm",java.util.Locale.getDefault()).format(java.util.Date(trade.entryTime)) else "Legacy record"}",color=Muted,fontSize=9.sp)
                    Text("Closed: ${java.text.SimpleDateFormat("dd MMM, HH:mm",java.util.Locale.getDefault()).format(java.util.Date(trade.exitTime))}",color=Muted,fontSize=9.sp)
                    Text("${fmt(trade.entryPrice)} → ${fmt(trade.exitPrice)} • ${if(trade.pnl>=0) "PROFIT" else "LOSS"}",color=if(trade.pnl>=0)Green else Red,fontSize=10.sp)
                }
                HorizontalDivider(color=Muted.copy(alpha=.15f))
            }
        }
        Section("SPOT HOLDINGS","MANUAL TRACKING")
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Text("YOUR PORTFOLIO", color=Color.White, fontWeight=FontWeight.Bold)
            Button(onClick={show=true}) { Icon(Icons.Default.Add,null); Text(" Add asset") }
        }
        CardBox {
            Text("TOTAL VALUE",color=Muted,fontSize=10.sp)
            Text(fmt(total),color=Color.White,fontSize=29.sp,fontWeight=FontWeight.Bold)
            Text("USDT • Based on latest available prices",color=Muted,fontSize=10.sp)
        }
        if(vm.holdings.isEmpty()) {
            Text("No assets yet. Add a holding to track your portfolio.",color=Muted)
        } else {
            Column {
                vm.holdings.forEach { h ->
                    val price=vm.currentPrice(h.symbol)
                    val value=(price ?: 0.0)*h.quantity
                    val pnl=price?.let { (it-h.average)*h.quantity }
                    CardBox {
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                            Column { Text(h.symbol,color=Color.White,fontWeight=FontWeight.Bold); Text("${h.quantity} units • Avg ${fmt(h.average)}",color=Muted,fontSize=11.sp) }
                            Column(horizontalAlignment=Alignment.End) {
                                Text(price?.let{fmt(value)} ?: "Price unavailable",color=Color.White,fontWeight=FontWeight.Bold)
                                Text(pnl?.let { "${if(it>=0)"+" else ""}${fmt(it)} USDT" } ?: "P/L unavailable",color=if((pnl ?: 0.0)>=0)Green else Red,fontSize=11.sp)
                            }
                        }
                        TextButton(onClick={vm.removeHolding(h)}) { Text("Remove",color=Red) }
                    }
                }
            }
        }
    }
    if(show) AlertDialog(
        onDismissRequest={show=false}, title={Text("Add portfolio asset")},
        text={Column {
            OutlinedTextField(sym,{sym=it.uppercase()},label={Text("Trading pair")})
            OutlinedTextField(qty,{qty=it},label={Text("Quantity")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            OutlinedTextField(avg,{avg=it},label={Text("Average purchase price (USDT)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        }},
        confirmButton={TextButton(onClick={val q=qty.toDoubleOrNull();val a=avg.toDoubleOrNull();if(sym.endsWith("USDT")&&q!=null&&q>0&&a!=null&&a>0){vm.addHolding(Holding(sym,q,a));show=false}}){Text("Save")}},
        dismissButton={TextButton(onClick={show=false}){Text("Cancel")}}
    )
}
@Composable fun SettingsScreen(language:String,onLanguageChange:(String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section(tr("Settings",language),tr("Premium interface",language))
        CardBox {
            Text(tr("Language",language),color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp)
            Spacer(Modifier.height(8.dp))
            Box {
                OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()) {
                    Text(appLanguages.firstOrNull{it.code==language}?.name ?: "English",color=Color.White)
                    Spacer(Modifier.weight(1f));Icon(Icons.Default.ExpandMore,null,tint=Cyan)
                }
                DropdownMenu(expanded=expanded,onDismissRequest={expanded=false},modifier=Modifier.heightIn(max=360.dp).background(Panel)) {
                    appLanguages.forEach { lang -> DropdownMenuItem(text={Text(lang.name,color=Color.White)},onClick={expanded=false;onLanguageChange(lang.code)}) }
                }
            }
            Text("20 interface languages. Your selection is saved on this device.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=8.dp))
        }
        CardBox {
            Text("CHART & ANALYSIS",color=Color.White,fontWeight=FontWeight.Bold)
            Text("Responsive candlestick chart • pinch zoom • drag navigation • EMA 9/21/50/200 • Bollinger Bands • VWAP",color=Muted,fontSize=11.sp)
            Spacer(Modifier.height(12.dp))
            Text("INTELLIGENCE MODULES",color=Color.White,fontWeight=FontWeight.Bold)
            Text("Market Regime • Multi-Scenario • Liquidity • Mistake Learning • Smart Risk • Walk-Forward",color=Muted,fontSize=11.sp)
            Spacer(Modifier.height(12.dp))
            Text("AUTOMATION SAFETY",color=Color.White,fontWeight=FontWeight.Bold)
            Text("Auto Pilot is simulation-only. Review every signal and risk limit. No live exchange orders are sent by this app.",color=Muted,fontSize=11.sp)
        }
        CardBox {
            Text(tr("Data source",language),color=Color.White,fontWeight=FontWeight.Bold)
            Text("Binance Spot public REST API",color=Muted,fontSize=12.sp)
            Spacer(Modifier.height(14.dp))
            Text(tr("Privacy & safety",language),color=Color.White,fontWeight=FontWeight.Bold)
            Text("No API key is required. This app does not place trades, access private accounts, or submit orders.",color=Muted,fontSize=12.sp)
            Spacer(Modifier.height(14.dp))
            Text(tr("About",language),color=Color.White,fontWeight=FontWeight.Bold)
            Text("Version 1.0.0",color=Muted,fontSize=12.sp)
            Text("Technical indicators and scanner signals are rule-based analysis, not guaranteed outcomes or financial advice.",color=Muted,fontSize=12.sp)
        }
    }
}
@Composable fun AccountScreen(language:String) {
    val context=LocalContext.current
    val prefs= remember { context.getSharedPreferences("app_preferences",0) }
    var displayName by remember { mutableStateOf(prefs.getString("display_name","") ?: "") }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section(tr("My account",language),"ALPON OPERATOR PROFILE")
        CardBox {
            Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center) {
                Box(Modifier.size(154.dp).background(Brush.radialGradient(listOf(Blue.copy(alpha=.35f),Cyan.copy(alpha=.08f),Color.Transparent)),CircleShape),contentAlignment=Alignment.Center) {
                    Image(painter=painterResource(R.drawable.alpon_robot_avatar),contentDescription="ALPON robotic falcon profile",contentScale=ContentScale.Crop,modifier=Modifier.size(128.dp).clip(CircleShape))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(displayName.ifBlank { "ALPON OPERATOR" },color=Color.White,fontSize=20.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.align(Alignment.CenterHorizontally))
            Text("AI TRADING COMMAND CENTER",color=Gold,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=1.1.sp,modifier=Modifier.align(Alignment.CenterHorizontally).padding(bottom=14.dp))
            Text(tr("Display name",language),color=Muted,fontSize=11.sp)
            OutlinedTextField(value=displayName,onValueChange={displayName=it;saved=false},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Your name")})
            Button(onClick={prefs.edit().putString("display_name",displayName.trim()).apply();saved=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Blue)) { Icon(Icons.Default.Save,null);Spacer(Modifier.width(7.dp));Text(tr("Save",language)) }
            if(saved) Text("Profile saved on this device.",color=Green,fontSize=11.sp)
            Text("Local profile only. Real Binance orders are disabled; no exchange API credentials are stored.",color=Muted,fontSize=11.sp)
        }
    }
}
@Composable fun SupportScreen(language:String) {
    val context=LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Section(tr("Support",language),tr("Contact support",language))
        CardBox {
            Icon(Icons.Default.SupportAgent,null,tint=Cyan,modifier=Modifier.size(42.dp))
            Text(tr("Contact support",language),color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp)
            Text("For app questions and technical assistance, open the support Telegram channel.",color=Muted,fontSize=12.sp)
            Button(onClick={runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/alpon_alphon"))) }},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Send,null);Spacer(Modifier.width(8.dp));Text("Open Telegram support") }
        }
    }
}
fun fmt(v:Double):String=if(!v.isFinite())"—" else String.format(Locale.US,"%,.4f",v).trimEnd('0').trimEnd('.')
fun compact(v:Double)=when{v>=1e9->"%.2fB".format(v/1e9);v>=1e6->"%.2fM".format(v/1e6);v>=1e3->"%.2fK".format(v/1e3);else->"%.0f".format(v)}

@Composable fun BacktestingScreen(vm: SpotViewModel) {
    var capital by remember { mutableStateOf("1000") }
    var risk by remember { mutableStateOf("0.5") }
    val result = vm.backtestResult

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
    ) {
        Section("STRATEGY BACKTEST", "BINANCE SPOT")
        CardBox {
            Text("Historical market test", color=Color.White, fontSize=17.sp, fontWeight=FontWeight.Bold)
            Text("Pair: ${vm.symbol}   •   Interval: ${vm.interval}", color=Cyan, fontSize=12.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value=capital,
                onValueChange={capital=it},
                modifier=Modifier.fillMaxWidth(),
                singleLine=true,
                label={Text("Initial capital (USDT)")}
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value=risk,
                onValueChange={risk=it},
                modifier=Modifier.fillMaxWidth(),
                singleLine=true,
                label={Text("Risk per trade (%)")}
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick={
                    val c=capital.toDoubleOrNull()
                    val r=risk.toDoubleOrNull()
                    if(c!=null && r!=null && c>0 && r>0 && r<=10) {
                        vm.runBacktest(c,r)
                    }
                },
                enabled=!vm.backtestLoading && !vm.walkForwardLoading,
                modifier=Modifier.fillMaxWidth()
            ) {
                Text(if(vm.backtestLoading) "Loading history and testing..." else "RUN BACKTEST")
            }
            Text(
                "Uses historical Binance candles, 0.5% default risk, daily/weekly loss pauses and a 3-loss circuit breaker. Simulation only; future results can differ.",
                color=Muted, fontSize=10.sp
            )
        }

        Section("WALK-FORWARD VALIDATION", "OUT-OF-SAMPLE TEST")
        CardBox {
            Text("Train → freeze parameters → test unseen candles", color=Color.White, fontSize=14.sp, fontWeight=FontWeight.Bold)
            Text("Rolling chronological windows: 60% training, 20% unseen test, 20% step. The engine tunes reward/risk only on each training window and keeps test trades separate.", color=Muted, fontSize=11.sp)
            Spacer(Modifier.height(10.dp))
            Button(
                onClick={
                    val c=capital.toDoubleOrNull() ?: 1000.0
                    val r=risk.toDoubleOrNull() ?: 0.5
                    if(c>0 && r>0 && r<=10) vm.runWalkForward(c,r)
                },
                enabled=!vm.walkForwardLoading && !vm.backtestLoading,
                modifier=Modifier.fillMaxWidth()
            ) { Text(if(vm.walkForwardLoading) "RUNNING WALK-FORWARD..." else "RUN WALK-FORWARD TEST") }
            Text("Training candidates: reward/risk 1.5, 2.0, 2.5, 3.0. Each test fold starts with fresh simulation capital; the compounded figure is an aggregate, not one continuous account path.", color=Muted, fontSize=10.sp)
        }

        vm.walkForwardError?.let { error ->
            CardBox { Text(error, color=Red, fontSize=12.sp) }
        }
        vm.walkForwardResult?.let { wf ->
            Section("UNSEEN TEST RESULTS", "${wf.profitableTestFolds}/${wf.totalTestFolds} PROFITABLE WINDOWS")
            CardBox {
                Text("Compounded test-window return", color=Muted, fontSize=11.sp)
                Text("${if(wf.compoundedOutOfSampleReturnPercent>=0) "+" else ""}${String.format(Locale.US,"%.2f",wf.compoundedOutOfSampleReturnPercent)}%", color=if(wf.compoundedOutOfSampleReturnPercent>=0) Green else Red, fontSize=25.sp, fontWeight=FontWeight.Bold)
                val wfMetrics=listOf(
                    "Unseen test trades" to wf.outOfSampleTrades.toString(),
                    "Test win rate" to (if(wf.outOfSampleTrades>0) String.format(Locale.US,"%.1f",wf.outOfSampleWins.toDouble()/wf.outOfSampleTrades*100.0)+"%" else "N/A"),
                    "Average test return" to String.format(Locale.US,"%.2f%%",wf.averageOutOfSampleReturnPercent),
                    "Average test drawdown" to String.format(Locale.US,"%.2f%%",wf.averageOutOfSampleDrawdownPercent),
                    "Profitable test windows" to "${wf.profitableTestFolds} / ${wf.totalTestFolds}",
                    "Selected reward/risk" to wf.selectedParameters.joinToString(", ") { String.format(Locale.US,"%.1f",it) }
                )
                wfMetrics.forEach { (label,value) ->
                    Row(Modifier.fillMaxWidth().padding(vertical=5.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(label,color=Muted,fontSize=11.sp)
                        Text(value,color=Color.White,fontSize=11.sp,fontWeight=FontWeight.SemiBold)
                    }
                }
                HorizontalDivider(color=Muted.copy(alpha=.2f), modifier=Modifier.padding(vertical=8.dp))
                Text(wf.warning, color=if(wf.profitableTestFolds==wf.totalTestFolds && wf.folds.all{it.trainingReliable}) Cyan else Red, fontSize=11.sp)
            }
            wf.folds.forEachIndexed { index, fold ->
                CardBox {
                    Text("FOLD ${index+1}", color=Cyan, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    Text("Train return ${String.format(Locale.US,"%.2f",fold.trainingReturnPercent)}% • ${fold.trainingTrades} trades", color=Muted, fontSize=10.sp)
                    Text("Frozen R/R ${String.format(Locale.US,"%.1f",fold.selectedRewardRisk)}", color=Color.White, fontSize=12.sp)
                    Text("UNSEEN TEST: ${if(fold.testReturnPercent>=0) "+" else ""}${String.format(Locale.US,"%.2f",fold.testReturnPercent)}% • ${fold.testTrades} trades • DD ${String.format(Locale.US,"%.2f",fold.testDrawdownPercent)}%", color=if(fold.testReturnPercent>=0) Green else Red, fontSize=11.sp)
                    if(!fold.trainingReliable) Text("Low training sample: fewer than 5 trades", color=Red, fontSize=10.sp)
                }
            }
        }

        if(vm.backtestError!=null) {
            CardBox {
                Text(vm.backtestError!!, color=Red, fontSize=12.sp)
            }
        }

        if(result!=null) {
            Section("PERFORMANCE", "${result.totalTrades} TRADES")
            CardBox {
                Text("Ending balance", color=Muted, fontSize=11.sp)
                Text("${fmt(result.endingBalance)} USDT", color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Bold)
                val profitColor=if(result.netProfit>=0) Green else Red
                Text(
                    "${if(result.netProfit>=0) "+" else ""}${fmt(result.netProfit)} USDT  (${String.format(Locale.US,"%.2f",result.totalReturnPercent)}%)",
                    color=profitColor, fontSize=14.sp, fontWeight=FontWeight.Bold
                )
                HorizontalDivider(color=Muted.copy(alpha=.2f), modifier=Modifier.padding(vertical=12.dp))
                val metrics=listOf(
                    "Initial capital" to "${fmt(result.initialCapital)} USDT",
                    "Total trades" to result.totalTrades.toString(),
                    "Wins / Losses" to "${result.wins} / ${result.losses}",
                    "Win rate" to "${String.format(Locale.US,"%.2f",result.winRate)}%",
                    "Profit factor" to (result.profitFactor?.let{String.format(Locale.US,"%.2f",it)} ?: "N/A"),
                    "Max drawdown" to "${String.format(Locale.US,"%.2f",result.maxDrawdownPercent)}%",
                    "Total fees" to "${fmt(result.totalFees)} USDT",
                    "Signals evaluated" to result.signalsEvaluated.toString()
                )
                metrics.forEach { (label,value) ->
                    Row(Modifier.fillMaxWidth().padding(vertical=5.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(label,color=Muted,fontSize=12.sp)
                        Text(value,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.SemiBold)
                    }
                }
            }

            Section("RECENT TRADES", "LAST 10")
            CardBox {
                if(result.trades.isEmpty()) {
                    Text("No trades were generated for this history.",color=Muted,fontSize=12.sp)
                } else {
                    result.trades.takeLast(10).asReversed().forEach { trade ->
                        Column(Modifier.fillMaxWidth().padding(vertical=7.dp)) {
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                                Text(trade.result,color=if(trade.pnl>=0) Green else Red,fontWeight=FontWeight.Bold,fontSize=12.sp)
                                Text("${if(trade.pnl>=0) "+" else ""}${fmt(trade.pnl)} USDT",color=if(trade.pnl>=0) Green else Red,fontSize=12.sp)
                            }
                            Text(
                                "Entry ${fmt(trade.entryPrice)}  →  Exit ${fmt(trade.exitPrice)}",
                                color=Color.White,fontSize=11.sp
                            )
                            Text(
                                "${trade.exitReason}  •  ${String.format(Locale.US,"%.2f",trade.pnlPercent)}%",
                                color=Muted,fontSize=10.sp
                            )
                        }
                        HorizontalDivider(color=Muted.copy(alpha=.15f))
                    }
                }
            }
        }
    }
}

@Composable
fun PaperTradingScreen(vm:SpotViewModel) {
    var amount by remember { mutableStateOf("100") }
    val price=if(vm.liveStatus=="LIVE" && vm.ticker?.symbol==vm.symbol) vm.ticker?.lastPrice?.toDoubleOrNull()?.takeIf{it.isFinite() && it>0} else null
    val position=vm.paperPositions.firstOrNull{it.symbol==vm.symbol}
    val unrealized=if(position!=null && price!=null && price>0)
        position.quantity*price*0.999-position.invested else null

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
    ) {
        Section("PAPER TRADING","SIMULATION")
        CardBox {
            Text("VIRTUAL BALANCE",color=Muted,fontSize=11.sp)
            Text("${fmt(vm.paperBalance)} USDT",color=Color.White,fontSize=27.sp,fontWeight=FontWeight.Bold)
            Text("Starting balance: 10,000 USDT",color=Muted,fontSize=10.sp)
        }

        Section("LIVE MARKET","${vm.symbol}")
        CardBox {
            Text("Binance WebSocket: ${vm.liveStatus}",color=if(vm.liveStatus=="LIVE") Green else Red,fontSize=11.sp)
            Text(
                price?.let{"${fmt(it)} USDT"} ?: "Waiting for live price...",
                color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Bold
            )
            Text("Selected pair: ${vm.symbol}",color=Muted,fontSize=11.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value=amount,
                onValueChange={amount=it},
                modifier=Modifier.fillMaxWidth(),
                singleLine=true,
                label={Text("Buy amount (USDT)")},
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal)
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick={vm.paperBuy(vm.symbol,price ?: 0.0,amount.toDoubleOrNull() ?: 0.0)},
                enabled=price!=null && price>0 && position==null,
                modifier=Modifier.fillMaxWidth()
            ) {
                Text("PAPER BUY")
            }
            if(position!=null) {
                Button(
                    onClick={vm.paperSell(vm.symbol,price ?: 0.0)},
                    enabled=price!=null && price>0,
                    modifier=Modifier.fillMaxWidth()
                ) {
                    Text("PAPER SELL")
                }
            }
            vm.paperMessage?.let {
                Text(it,color=Cyan,fontSize=11.sp)
            }
            Text("Simulation only • 0.1% fee per side • No real funds used",color=Muted,fontSize=10.sp)
        }

        Section("OPEN POSITIONS","${vm.paperPositions.size}")
        CardBox {
            if(vm.paperPositions.isEmpty()) {
                Text("No open paper positions.",color=Muted,fontSize=12.sp)
            } else {
                vm.paperPositions.forEach { item ->
                    Column(Modifier.fillMaxWidth().padding(vertical=6.dp)) {
                        Text(item.symbol,color=Color.White,fontWeight=FontWeight.Bold)
                        Text("Quantity: ${fmt(item.quantity)}",color=Muted,fontSize=11.sp)
                        Text("Entry: ${fmt(item.entryPrice)} USDT",color=Muted,fontSize=11.sp)
                        Text("Invested: ${fmt(item.invested)} USDT",color=Muted,fontSize=11.sp)
                        if(item.symbol==vm.symbol && unrealized!=null) {
                            Text(
                                "Estimated PnL: ${fmt(unrealized)} USDT",
                                color=if(unrealized>=0) Green else Red,
                                fontWeight=FontWeight.Bold,fontSize=12.sp
                            )
                        }
                    }
                    HorizontalDivider(color=Muted.copy(alpha=.2f))
                }
            }
        }

        Section("TRADE HISTORY","${vm.paperTrades.size} CLOSED")
        CardBox {
            if(vm.paperTrades.isEmpty()) {
                Text("Completed paper trades will appear here.",color=Muted,fontSize=12.sp)
            } else {
                vm.paperTrades.takeLast(20).asReversed().forEach { trade ->
                    Column(Modifier.fillMaxWidth().padding(vertical=7.dp)) {
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                            Text(trade.symbol,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            Text(
                                "${if(trade.pnl>=0) "+" else ""}${fmt(trade.pnl)} USDT",
                                color=if(trade.pnl>=0) Green else Red,fontSize=12.sp
                            )
                        }
                        Text(
                            "Entry ${fmt(trade.entryPrice)} → Exit ${fmt(trade.exitPrice)}",
                            color=Muted,fontSize=10.sp
                        )
                    }
                    HorizontalDivider(color=Muted.copy(alpha=.15f))
                }
            }
        }
    }
}
