package com.alpon.spotai.domain

import com.alpon.spotai.data.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class IndicatorReading(val name: String, val value: String, val bias: Int, val group: String)
data class Signal(
    val action: String, val score: Int, val trend: String, val entry: Double, val stop: Double,
    val tp1: Double, val tp2: Double, val tp3: Double, val rr: Double, val explanation: String,
    val ema9: Double, val ema21: Double, val ema50: Double, val ema200: Double,
    val rsi: Double, val macd: Double, val support: Double, val resistance: Double,
    val indicators: List<IndicatorReading>, val bullishVotes: Int, val bearishVotes: Int,
    val neutralVotes: Int, val atr: Double, val entryTiming: String, val holdingWindow: String,
    val candleCloseAt: String
)

/** Deterministic multi-indicator analysis. All calculations use exchange candles; no synthetic market values. */
object TechnicalAnalysis {
    private val periods = listOf(5, 7, 9, 10, 12, 14, 20, 21, 26, 28, 30, 50, 100, 200)
    private fun ema(v: List<Double>, p: Int): Double {
        if (v.size < p) return Double.NaN
        val k = 2.0 / (p + 1.0)
        var e = v.take(p).average()
        for (x in v.drop(p)) e = x * k + e * (1.0 - k)
        return e
    }
    private fun sma(v: List<Double>, p: Int) = if (v.size < p) Double.NaN else v.takeLast(p).average()
    private fun rsi(v: List<Double>, p: Int): Double {
        if (v.size <= p) return Double.NaN
        val d = v.zipWithNext { a, b -> b - a }.takeLast(p)
        val gain = d.sumOf { max(it, 0.0) } / p
        val loss = d.sumOf { max(-it, 0.0) } / p
        return if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)
    }
    private fun atr(c: List<Candle>, p: Int): Double {
        if (c.size <= p) return Double.NaN
        return c.takeLast(p).mapIndexed { i, x ->
            val prev = c[c.size - p + i - 1].close
            max(x.high - x.low, max(abs(x.high - prev), abs(x.low - prev)))
        }.average()
    }
    private fun bias(v: Double, neutral: Double = 0.0): Int = when { !v.isFinite() -> 0; v > neutral -> 1; v < -neutral -> -1; else -> 0 }
    private fun fmt(v: Double) = if (v.isFinite()) String.format(java.util.Locale.US, "%.5f", v) else "N/A"

    fun analyze(input: List<Candle>, interval: String = "1h"): Signal? {
        // Binance's newest kline can still be forming. Exclude it so a moving candle cannot repaint a signal.
        val c = if (input.size > 210) input.dropLast(1) else input
        if (c.size < 210) return null
        val close = c.map { it.close }; val high = c.map { it.high }; val low = c.map { it.low }; val volume = c.map { it.volume }
        val price = close.last(); if (!price.isFinite() || price <= 0.0) return null
        val readings = mutableListOf<IndicatorReading>()
        fun add(name: String, value: Double, b: Int, group: String) { readings += IndicatorReading(name, fmt(value), b, group) }

        // Moving-average family: EMA and SMA trend/cross checks across short, medium and long horizons.
        listOf(5,9,12,20,21,26,50,100,200).forEach { p -> val e=ema(close,p); add("EMA $p",e,bias(price-e),"Trend") }
        listOf(5,10,20,21,30,50,100,200).forEach { p -> val s=sma(close,p); add("SMA $p",s,bias(price-s),"Trend") }
        listOf(7,9,14,21,28).forEach { p -> val x=rsi(close,p); add("RSI $p",x,when { x.isNaN()->0; x<30->1; x>70->-1; x>=50->1; else->-1 },"Momentum") }
        listOf(5,9,14,20,50).forEach { p -> val x=if(close.size>p) (price/close[close.size-p-1]-1)*100 else Double.NaN; add("ROC $p",x,bias(x),"Momentum") }
        listOf(5,9,14,20,50).forEach { p -> val x=if(close.size>p) price-close[close.size-p-1] else Double.NaN; add("Momentum $p",x,bias(x),"Momentum") }
        listOf(10,20,30,50).forEach { p -> val m=sma(close,p); val sd=if(close.size>=p) sqrt(close.takeLast(p).map{(it-m)*(it-m)}.average()) else Double.NaN; val upper=m+2*sd; val lower=m-2*sd; val pb=if(upper>lower)(price-lower)/(upper-lower) else Double.NaN; add("Bollinger %B $p",pb,when{pb.isNaN()->0;pb<0.15->1;pb>0.85->-1;pb>=0.5->1;else->-1},"Volatility") }
        listOf(9,14,21,28).forEach { p -> val hh=high.takeLast(p).maxOrNull()!!; val ll=low.takeLast(p).minOrNull()!!; val k=if(hh>ll)(price-ll)/(hh-ll)*100 else 50.0; add("Stochastic %K $p",k,when{k<20->1;k>80->-1;k>=50->1;else->-1},"Momentum") }
        listOf(9,14,21,28).forEach { p -> val hh=high.takeLast(p).maxOrNull()!!; val ll=low.takeLast(p).minOrNull()!!; val w=if(hh>ll)(hh-price)/(hh-ll)*-100 else -50.0; add("Williams %R $p",w,when{w < -80->1;w > -20->-1;w>=-50->1;else->-1},"Momentum") }
        listOf(14,20,28,50).forEach { p -> val tp=c.takeLast(p).map{(it.high+it.low+it.close)/3}; val mean=tp.average(); val md=tp.map{abs(it-mean)}.average(); val x=if(md>0)(tp.last()-mean)/(.015*md) else 0.0; add("CCI $p",x,when{x < -100->1;x > 100->-1;x>=0->1;else->-1},"Momentum") }
        listOf(7,14,21,28).forEach { p -> val x=atr(c,p); add("ATR $p",x,0,"Volatility") }
        listOf(7,14,21,28).forEach { p -> val tp=c.takeLast(p).map{(it.high+it.low+it.close)/3}; val mf=tp.zip(c.takeLast(p)).map{(t,k)->t*k.volume}; val pos=mf.indices.filter{it>0 && tp[it]>tp[it-1]}.sumOf{mf[it]}; val neg=mf.indices.filter{it>0 && tp[it]<tp[it-1]}.sumOf{mf[it]}; val x=if(neg==0.0)100.0 else 100-100/(1+pos/neg); add("MFI $p",x,when{x<20->1;x>80->-1;x>=50->1;else->-1},"Volume") }
        listOf(5,10,20,50).forEach { p -> val obv=c.takeLast(p+1).zipWithNext().sumOf{(a,b)->when{b.close>a.close->b.volume;b.close<a.close->-b.volume;else->0.0}}; add("OBV trend $p",obv,bias(obv),"Volume") }
        listOf(5,10,20,50).forEach { p -> val avg=sma(volume,p); val ratio=if(avg>0)volume.last()/avg else Double.NaN; add("Volume ratio $p",ratio,if(ratio>1.15)bias(price-close[max(0,close.lastIndex-1)]) else 0,"Volume") }
        listOf(7,14,21,28).forEach { p -> val xs=c.takeLast(p+1); var plus=0.0; var minus=0.0; var tr=0.0; for(i in 1 until xs.size){ val up=xs[i].high-xs[i-1].high; val down=xs[i-1].low-xs[i].low; plus+=if(up>down&&up>0)up else 0.0; minus+=if(down>up&&down>0)down else 0.0; tr+=max(xs[i].high-xs[i].low,max(abs(xs[i].high-xs[i-1].close),abs(xs[i].low-xs[i-1].close))) }; val pdi=if(tr>0)plus/tr*100 else 0.0; val mdi=if(tr>0)minus/tr*100 else 0.0; val strength=if(pdi+mdi>0)abs(pdi-mdi)/(pdi+mdi)*100 else 0.0; add("ADX / DI $p",strength,bias(pdi-mdi),"Trend") }
        listOf(10,20,50,100).forEach { p -> val hh=high.takeLast(p).maxOrNull()!!; val ll=low.takeLast(p).minOrNull()!!; val pos=if(hh>ll)(price-ll)/(hh-ll) else .5; add("Donchian position $p",pos,bias(pos-.5,.08),"Breakout") }
        listOf(14,25,50).forEach { p -> val hi=high.takeLast(p).indexOf(high.takeLast(p).maxOrNull()); val lo=low.takeLast(p).indexOf(low.takeLast(p).minOrNull()); val up=100.0*(p-1-hi)/p; val dn=100.0*(p-1-lo)/p; add("Aroon oscillator $p",up-dn,bias(up-dn,10.0),"Trend") }
        listOf(10,20,50).forEach { p -> val money=c.takeLast(p).sumOf{ k -> val range=(k.high-k.low).takeIf{it!=0.0}?:1e-12; (((k.close-k.low)-(k.high-k.close))/range)*k.volume }; val vol=c.takeLast(p).sumOf{it.volume}; val x=if(vol>0)money/vol else 0.0; add("Chaikin money flow $p",x,bias(x,.05),"Volume") }
        // MACD variants, Ichimoku components, VWAP, pivots, candle pattern checks.
        listOf(12 to 26, 8 to 21, 19 to 39).forEach { (a,b) -> val m=ema(close,a)-ema(close,b); add("MACD $a/$b",m,bias(m),"Momentum") }
        val tenkan=(high.takeLast(9).maxOrNull()!!+low.takeLast(9).minOrNull()!!)/2
        val kijun=(high.takeLast(26).maxOrNull()!!+low.takeLast(26).minOrNull()!!)/2
        val spanB=(high.takeLast(52).maxOrNull()!!+low.takeLast(52).minOrNull()!!)/2
        add("Ichimoku Tenkan",tenkan,bias(price-tenkan),"Trend"); add("Ichimoku Kijun",kijun,bias(price-kijun),"Trend"); add("Ichimoku cloud A",(tenkan+kijun)/2,bias(price-(tenkan+kijun)/2),"Trend"); add("Ichimoku cloud B",spanB,bias(price-spanB),"Trend")
        val vwap=c.takeLast(50).let{xs->xs.sumOf{it.close*it.volume}/xs.sumOf{it.volume}.coerceAtLeast(1e-12)}; add("VWAP 50",vwap,bias(price-vwap),"Volume")
        val prev=c[c.lastIndex-1]; val pivot=(prev.high+prev.low+prev.close)/3
        listOf("Pivot" to pivot,"R1" to (2*pivot-prev.low),"S1" to (2*pivot-prev.high),"R2" to (pivot+prev.high-prev.low),"S2" to (pivot-prev.high+prev.low)).forEach{(n,v)->add("Classic $n",v,bias(price-v),"Levels")}
        val last=c.last(); val body=abs(last.close-last.open); val span=(last.high-last.low).coerceAtLeast(1e-12); val upper=last.high-max(last.open,last.close); val lower=min(last.open,last.close)-last.low
        add("Bullish candle body",body,if(last.close>last.open)1 else -1,"Candles"); add("Upper wick",upper,if(upper>body*1.8)-1 else 0,"Candles"); add("Lower wick",lower,if(lower>body*1.8)1 else 0,"Candles"); add("Candle close location",(last.close-last.low)/span,bias((last.close-last.low)/span-.5,.12),"Candles")
        val prior=c[c.lastIndex-1]; val engulfBull=last.close>last.open && prior.close<prior.open && last.close>=prior.open && last.open<=prior.close; val engulfBear=last.close<last.open && prior.close>prior.open && last.open>=prior.close && last.close<=prior.open
        add("Engulfing pattern",if(engulfBull)1.0 else if(engulfBear)-1.0 else 0.0,if(engulfBull)1 else if(engulfBear)-1 else 0,"Candles")
        add("Doji detector",body/span,0,"Candles"); add("Hammer detector",if(lower>body*2 && upper<body)1.0 else 0.0,if(lower>body*2&&upper<body)1 else 0,"Candles"); add("Shooting star detector",if(upper>body*2&&lower<body)1.0 else 0.0,if(upper>body*2&&lower<body)-1 else 0,"Candles")
        // Additional independent period checks make the 100-check matrix explicit and inspectable.
        listOf(6,8,13,16,18,24,34,40,60,80,120,150).forEach { p -> val e=ema(close,p); val prior=if(close.size>p+3) ema(close.dropLast(3),p) else Double.NaN; add("EMA slope $p",e,bias(e-prior),"Trend") }
        listOf(6,8,13,16,18,24,34,40,60,80,120,150).forEach { p -> val x=rsi(close,p); add("RSI regime $p",x,when{x.isNaN()->0;x<35->1;x>65->-1;x>=50->1;else->-1},"Momentum") }

        val bullish=readings.count{it.bias>0}; val bearish=readings.count{it.bias<0}; val neutral=readings.size-bullish-bearish
        // Give each indicator family equal influence so families with many parameter variants do not dominate.
        val familyScores=readings.groupBy{it.group}.values.map{family->family.map{it.bias.toDouble()}.average()}
        val net=familyScores.average().takeIf{it.isFinite()}?:0.0
        val e9=ema(close,9); val e21=ema(close,21); val e50=ema(close,50); val e200=ema(close,200); val r=rsi(close,14); val macd=ema(close,12)-ema(close,26)
        val trend=when{e9>e21&&e21>e50&&price>e200->"Strong bullish";e9<e21&&e21<e50&&price<e200->"Strong bearish";else->"Mixed / sideways"}
        val action=when{net>=.22 && e9>e21 && r in 42.0..70.0->"BUY";net<=-.22&&e9<e21&&r in 30.0..58.0->"SELL";else->"WAIT"}
        val confidence=(50+net*45).toInt().coerceIn(0,100)
        val volatility=atr(c,14).takeIf{it.isFinite()&&it>0}?:return null
        val support=c.takeLast(50).minOf{it.low}; val resistance=c.takeLast(50).maxOf{it.high}
        val long=action!="SELL"; val stopDistance=max(volatility*1.6,price*.002)
        val stop=if(long)min(price-stopDistance,support-volatility*.15) else max(price+stopDistance,resistance+volatility*.15)
        val risk=abs(price-stop).coerceAtLeast(price*.001)
        val tp1=if(long)price+risk else price-risk; val tp2=if(long)price+2*risk else price-2*risk; val tp3=if(long)price+3*risk else price-3*risk
        val mins=when(interval){"1m"->5..30;"3m"->15..60;"5m"->30..180;"15m"->60..360;"30m"->120..720;"1h"->240..1440;"2h"->480..2880;"4h"->720..4320;"6h"->1440..5760;"12h"->2880..10080;"1d"->1440..10080;else->240..1440}
        val intervalMs=when(interval){"1m"->60_000L;"3m"->180_000L;"5m"->300_000L;"15m"->900_000L;"30m"->1_800_000L;"1h"->3_600_000L;"2h"->7_200_000L;"4h"->14_400_000L;"6h"->21_600_000L;"12h"->43_200_000L;"1d"->86_400_000L;else->3_600_000L}
        val now=System.currentTimeMillis(); val liveOpen=input.lastOrNull()?.time?:now
        var nextClose=liveOpen+intervalMs
        while(nextClose<=now) nextClose+=intervalMs
        val closeClock=java.time.Instant.ofEpochMilli(nextClose).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss z"))
        val waitMinutes=((nextClose-now).coerceAtLeast(0L)/60_000L)
        val timing=when(action){"BUY"->"BUY setup only: wait about $waitMinutes min for the active $interval candle to close ($closeClock). Enter only if the closed candle confirms the setup and price retests/holds the level; do not chase.";"SELL"->"For Spot holdings: wait for candle confirmation before reducing/exiting. Spot SELL is not a short instruction. Next candle close: about $waitMinutes min ($closeClock).";else->"WAIT — no entry now. Recheck after the $interval candle closes in about $waitMinutes min ($closeClock), then wait for breakout/retest confirmation."}
        return Signal(action,confidence,trend,price,stop,tp1,tp2,tp3,2.0,
            "$bullish bullish / $bearish bearish / $neutral neutral checks across ${readings.size} indicator and price-action readings. Signals are confirmations, not predictions.",
            e9,e21,e50,e200,r,macd,support,resistance,readings,bullish,bearish,neutral,volatility,timing,"Estimated review window: ${mins.first}–${mins.last} minutes (not a guaranteed holding time).","Next candle close: $closeClock (device local time). Current live candle may change.")
    }
}
